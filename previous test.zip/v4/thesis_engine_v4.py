#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════╗
║   THESIS ANALYSIS ENGINE  v4                                         ║
║   "Investor Attention and Stock Market Volatility:                   ║
║    Evidence from Digital Search Data"                                ║
║                                                                      ║
║   Built on v3 — 15 improvements, pure numpy/scipy, no external deps  ║
║                                                                      ║
║   FIX  1 – GAZP Aug-2022 extraordinary dividend event dummy          ║
║   FIX  2 – Granger F never clamped to 0; NaN propagates properly     ║
║   NEW  3 – Benjamini-Hochberg FDR multiple-testing correction        ║
║   NEW  4 – HAR-RV model  (Corsi 2009) ± ASVI extension              ║
║   NEW  5 – GARCH(1,1) + ASVI-in-variance  (scipy.optimize MLE)      ║
║   NEW  6 – Driscoll-Kraay SE for panel (cross-sectional robust)      ║
║   NEW  7 – Permutation Granger test  (1000 shuffles, per company)   ║
║   NEW  8 – Moving-block bootstrap CI  (block=T^(1/3), B=1000)       ║
║   NEW  9 – Quantile regression  τ=0.25/0.50/0.75/0.90 (scipy LP)   ║
║   NEW 10 – Event study: ASVI spike windows ±4 weeks                 ║
║   NEW 11 – Pre-trend rolling correlation  (52-week pre-crisis)       ║
║   NEW 12 – Power / MDE analysis  (non-central t distribution)        ║
║   NEW 13 – Falsification test  (date-shuffled ASVI within firm)      ║
║   NEW 14 – AFLT ΔVol model (M1d for non-stationary volatility)      ║
║   NEW 15 – JSON manifest / deterministic seed / timing log           ║
║                                                                      ║
║   HOW TO RUN                                                         ║
║     python thesis_engine_v4.py                                       ║
║   Expects MASTER_DATASET.csv in the same directory.                  ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import os, sys, json, time, warnings, traceback
from datetime import datetime

import numpy as np
import pandas as pd
import scipy.stats as st
from scipy.optimize import minimize, linprog
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

warnings.filterwarnings("ignore")

# ── Deterministic seed (FIX 15) ──────────────────────────────────────
SEED = 20260308
np.random.seed(SEED)

# ═══════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════

_HERE   = os.path.dirname(os.path.abspath(__file__))
IN_FILE = os.path.join(_HERE, "MASTER_DATASET.csv")
OUTDIR  = os.path.join(_HERE, "analysis_output_v4")
GDIR    = os.path.join(OUTDIR, "graphs")

BREAK_2022_START = pd.Timestamp("2022-02-21")
BREAK_2022_END   = pd.Timestamp("2022-03-28")
BREAK_YNDX_2024  = pd.Timestamp("2024-07-01")
# FIX 1: GAZP extraordinary dividend reversal Aug-Sep 2022
GAZP_EVENT_START = pd.Timestamp("2022-07-25")
GAZP_EVENT_END   = pd.Timestamp("2022-09-12")

INDEX_TICKERS = {"MOEX"}

SECTOR_COLORS = {
    "Banking":      "#2166ac",
    "Energy":       "#d6604d",
    "ConsumerTech": "#4dac26",
}
COMPANY_ORDER = [
    "SBER","GAZP","LKOH","NVTK","ROSN","GMKN",
    "AFLT","MGNT","PIKK","MTSS","YNDX",
    "VTBR","MOEX","BSPB","TCSG",
]

DPI            = 150
ALPHA          = 0.05
WINSOR_RET_SD  = 3.5
WINSOR_ASVI_SD = 4.0
LNVOL_DROP_PCT = 0.30
MIN_OBS        = 50
HAC_LAGS       = 4
N_BOOT         = 1000
N_PERM         = 1000
N_FALSE        = 200
HAR_LAGS_W     = 4
HAR_LAGS_M     = 13
QUANTILE_TAUS  = [0.25, 0.50, 0.75, 0.90]

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor":   "#f8f8f8",
    "axes.grid":        True,
    "grid.color":       "white",
    "grid.linewidth":   0.8,
    "axes.spines.top":  False,
    "axes.spines.right":False,
    "font.family":      "DejaVu Sans",
    "font.size":        9,
    "axes.titlesize":   10,
    "axes.labelsize":   9,
    "legend.fontsize":  8,
})

# ═══════════════════════════════════════════════════════════════════════
# LOGGING + MANIFEST  (FIX 15)
# ═══════════════════════════════════════════════════════════════════════

_LOG      = []
_MANIFEST = {"seed": SEED, "generated": str(datetime.now()),
             "timings": {}, "summaries": {}}
_T0       = time.time()

def log(msg, level=""):
    tag = {"WARN":"⚠ ","ERROR":"✗ ","OK":"✓ "}.get(level, "  ")
    print(f"  {tag}{msg}")
    _LOG.append(f"[{level or 'INFO'}] {msg}")

def section(title):
    bar = "═" * 68
    print(f"\n  {bar}\n  {title}\n  {bar}")
    _LOG.append(f"\n{'='*72}\n{title}\n{'='*72}")
    _MANIFEST["timings"][title] = round(time.time() - _T0, 2)

def sig_stars(p):
    if p is None or (isinstance(p, float) and np.isnan(p)): return ""
    if p < 0.01: return "***"
    if p < 0.05: return "**"
    if p < 0.10: return "*"
    return ""

def _save_manifest():
    path = os.path.join(OUTDIR, "MANIFEST_v4.json")
    _MANIFEST["total_runtime_sec"] = round(time.time() - _T0, 2)
    with open(path, "w") as f:
        json.dump(_MANIFEST, f, indent=2, default=str)
    log(f"Manifest saved: {path}", "OK")

# ═══════════════════════════════════════════════════════════════════════
# SECTION 1: CORE STATISTICAL UTILITIES
# ═══════════════════════════════════════════════════════════════════════

def ols_hac(y, X):
    """OLS with Newey-West HAC SE (bandwidth=HAC_LAGS=4)."""
    mask = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    y_, X_ = y[mask], X[mask]
    n, k = X_.shape
    if n < k + 10:
        return None
    try:
        XtX_inv = np.linalg.pinv(X_.T @ X_)
    except Exception:
        return None
    b = XtX_inv @ X_.T @ y_
    resid = y_ - X_ @ b
    rss = float(resid @ resid)
    tss = float(((y_ - y_.mean())**2).sum())
    r2  = 1 - rss/tss if tss > 1e-20 else np.nan
    ar2 = 1 - (1-r2)*(n-1)/(n-k) if not np.isnan(r2) else np.nan
    Xe  = X_ * resid[:, None]
    S   = Xe.T @ Xe
    for j in range(1, HAC_LAGS + 1):
        w = 1 - j / (HAC_LAGS + 1)
        G = Xe[j:].T @ Xe[:-j]
        S += w * (G + G.T)
    V  = XtX_inv @ S @ XtX_inv * (n / (n - k))
    se = np.sqrt(np.maximum(np.diag(V), 0))
    t_ = np.where(se > 1e-20, b / se, np.nan)
    p_ = 2 * st.t.sf(np.abs(t_), df=n - k)
    return dict(coef=b, se=se, t=t_, p=p_, r2=r2, adj_r2=ar2,
                n=int(mask.sum()), rss=rss, resid=resid)


def adf_test(series, max_lags=6):
    """ADF test with MacKinnon (1994) finite-sample response-surface p-values."""
    s = pd.Series(series).dropna().values.astype(float)
    if len(s) < 25:
        return np.nan, np.nan, 0
    _mk = {
        0.010: (-3.43035, -6.5393, -16.786),
        0.025: (-2.86154, -2.8903, -4.234),
        0.050: (-2.56677, -1.5384, -2.809),
        0.100: (-2.23189, -1.2209, -1.226),
    }
    def _p(tau, n):
        cvs = {p: c[0]+c[1]/n+c[2]/(n*n) for p, c in _mk.items()}
        if tau <= cvs[0.010]: return 0.005
        if tau <= cvs[0.025]: return 0.015
        if tau <= cvs[0.050]: return 0.040
        if tau <= cvs[0.100]: return 0.075
        if tau <= -1.95:      return 0.20
        if tau <= -1.61:      return 0.35
        return 0.65
    dy = np.diff(s)
    best_aic, best_lag = np.inf, 0
    for lag in range(0, min(max_lags, len(dy)//5)+1):
        n_ = len(dy) - lag
        if n_ < 15: break
        y_ = dy[lag:]
        Xc = [s[lag:lag+n_]] + [dy[lag-j:lag-j+n_] for j in range(1, lag+1)]
        X_ = np.column_stack([np.ones(n_)] + Xc)
        r  = ols_hac(y_, X_)
        if r is None: continue
        aic = n_ * np.log(r["rss"]/n_) + 2 * X_.shape[1]
        if aic < best_aic: best_aic, best_lag = aic, lag
    lag = best_lag
    n_  = len(dy) - lag
    if n_ < 10: return np.nan, np.nan, lag
    y_  = dy[lag:]
    Xc  = [s[lag:lag+n_]] + [dy[lag-j:lag-j+n_] for j in range(1, lag+1)]
    X_  = np.column_stack([np.ones(n_)] + Xc)
    r   = ols_hac(y_, X_)
    if r is None: return np.nan, np.nan, lag
    adf = float(r["t"][1])
    return round(adf, 4), round(_p(adf, n_), 4), lag


def granger_test(y, x, max_lag=4):
    """
    Bivariate Granger causality F-test at lags 1, 2, 4.
    FIX 2: F is NOT clamped — negative F → NaN (numerical instability flag).
    """
    results = {}
    for lag in [1, 2, 4]:
        if lag > max_lag:
            continue
        df_ = pd.DataFrame({"y": y, "x": x})
        for j in range(1, lag+1):
            df_[f"yL{j}"] = df_["y"].shift(j)
            df_[f"xL{j}"] = df_["x"].shift(j)
        df_ = df_.dropna()
        if len(df_) < lag*2+25:
            results[lag] = (np.nan, np.nan)
            continue
        y_   = df_["y"].values
        ycol = [df_[f"yL{j}"].values for j in range(1, lag+1)]
        xcol = [df_[f"xL{j}"].values for j in range(1, lag+1)]
        Xr   = np.column_stack([np.ones(len(y_))] + ycol)
        Xu   = np.column_stack([np.ones(len(y_))] + ycol + xcol)
        rr   = ols_hac(y_, Xr)
        ru   = ols_hac(y_, Xu)
        if rr is None or ru is None:
            results[lag] = (np.nan, np.nan)
            continue
        n, ku    = ru["n"], Xu.shape[1]
        rss_diff = rr["rss"] - ru["rss"]
        if rss_diff < -1e-8:   # unrestricted worse than restricted → numerical issue
            results[lag] = (np.nan, np.nan)
            continue
        F = (rss_diff / lag) / (ru["rss"] / (n - ku))
        p = float(st.f.sf(F, lag, n - ku))
        results[lag] = (round(F, 4), round(p, 4))
    return results


def permutation_granger(y, x, n_perm=N_PERM, lag=1):
    """
    NEW 7: Permutation Granger test.
    Shuffles x within firm (preserving y autocorrelation).
    Returns (F_obs, p_perm, p_parametric).
    """
    rng   = np.random.default_rng(SEED)
    res   = granger_test(y, x, max_lag=lag)
    F_obs, p_par = res.get(lag, (np.nan, np.nan))
    if np.isnan(F_obs):
        return np.nan, np.nan, np.nan
    x_arr  = np.asarray(x)
    F_perm = []
    for _ in range(n_perm):
        xp      = rng.permutation(x_arr)
        rp      = granger_test(y, xp, max_lag=lag)
        Fp, _   = rp.get(lag, (np.nan, np.nan))
        if not np.isnan(Fp):
            F_perm.append(Fp)
    if not F_perm:
        return F_obs, np.nan, p_par
    p_perm = float(np.mean(np.array(F_perm) >= F_obs))
    return round(F_obs, 4), round(p_perm, 4), round(p_par, 4)


def block_bootstrap_ci(data_dict, n_boot=N_BOOT, ci_level=0.95):
    """
    NEW 8: Moving-block bootstrap CI for ASVI(t-1) coefficient.
    Block length b = ceil(T^(1/3)).
    data_dict: {"y": array, "X": array (incl intercept)}
    Returns (b_lo, b_hi, b_mean, b_std) or None.
    """
    rng   = np.random.default_rng(SEED+1)
    y_arr = data_dict["y"]
    X_arr = data_dict["X"]
    T     = len(y_arr)
    if T < MIN_OBS:
        return None
    r0 = ols_hac(y_arr, X_arr)
    if r0 is None or len(r0["coef"]) < 2:
        return None
    b      = max(4, int(np.ceil(T**(1/3))))
    blocks = [(y_arr[i:i+b], X_arr[i:i+b]) for i in range(T - b + 1)]
    n_bl   = int(np.ceil(T / b))
    boot_coefs = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(blocks), size=n_bl)
        ys  = np.concatenate([blocks[i][0] for i in idx])[:T]
        Xs  = np.concatenate([blocks[i][1] for i in idx])[:T]
        rb  = ols_hac(ys, Xs)
        if rb is not None and len(rb["coef"]) > 1:
            boot_coefs.append(rb["coef"][1])   # ASVI index
    if len(boot_coefs) < 50:
        return None
    bc  = np.array(boot_coefs)
    lo  = float(np.percentile(bc, (1 - ci_level)/2 * 100))
    hi  = float(np.percentile(bc, (1 - (1-ci_level)/2) * 100))
    return round(lo, 6), round(hi, 6), round(float(bc.mean()), 6), round(float(bc.std()), 6)


def bh_fdr(p_values, alpha=ALPHA):
    """
    NEW 3: Benjamini-Hochberg FDR correction.
    Returns array of adjusted p-values.
    """
    pv  = np.asarray(p_values, dtype=float)
    m   = len(pv)
    nan_mask = np.isnan(pv)
    out  = np.full(m, np.nan)
    vidx = np.where(~nan_mask)[0]
    if len(vidx) == 0:
        return out
    pv_v  = pv[vidx]
    order = np.argsort(pv_v)
    ranks = np.empty_like(order)
    ranks[order] = np.arange(1, len(pv_v)+1)
    adj  = pv_v * m / ranks
    adj_mono = np.minimum.accumulate(adj[::-1])[::-1]
    adj_clip = np.minimum(adj_mono, 1.0)
    out[vidx] = adj_clip[np.argsort(order)]
    return out


def driscoll_kraay_se(panel_df, y_col, x_cols, L=4):
    """
    NEW 6: Driscoll-Kraay (1998) SE for panel.
    Robust to heteroskedasticity, autocorrelation, AND cross-sectional dependence.
    """
    need = ["Ticker", "Week", y_col] + x_cols
    sub  = panel_df[[c for c in need if c in panel_df.columns]].dropna().copy()
    if len(sub) < 50 or "Week" not in sub.columns:
        return None
    for col in [y_col] + x_cols:
        sub[col] -= sub.groupby("Ticker")[col].transform("mean")
    y_ = sub[y_col].values
    X_ = np.column_stack([sub[c].values for c in x_cols])
    n, k  = X_.shape
    try:
        XtX_inv = np.linalg.pinv(X_.T @ X_)
    except Exception:
        return None
    b     = XtX_inv @ X_.T @ y_
    resid = y_ - X_ @ b
    rss   = float(resid @ resid)
    tss   = float(((y_ - y_.mean())**2).sum())
    r2    = 1 - rss/tss if tss > 1e-20 else np.nan
    ar2   = 1 - (1-r2)*(n-1)/(n-k) if not np.isnan(r2) else np.nan
    sub["_e"] = resid
    for j, col in enumerate(x_cols):
        sub[f"_Xe{j}"] = sub[col] * sub["_e"]
    xe_cols = [f"_Xe{j}" for j in range(k)]
    ht = sub.groupby("Week")[xe_cols].mean()
    ht_vals = ht.values
    T   = len(ht_vals)
    N   = sub.groupby("Week")["_e"].count().mean()
    S   = ht_vals.T @ ht_vals
    for j in range(1, L+1):
        w  = 1 - j/(L+1)
        Gj = ht_vals[j:].T @ ht_vals[:-j]
        S  += w * (Gj + Gj.T)
    S   *= T
    V_dk = XtX_inv @ S @ XtX_inv * (T / max(T - k, 1))
    se   = np.sqrt(np.maximum(np.diag(V_dk), 0))
    t_   = np.where(se > 1e-20, b / se, np.nan)
    p_   = 2 * st.t.sf(np.abs(t_), df=T - k)
    return dict(coef=b, se_dk=se, t_dk=t_, p_dk=p_,
                r2=r2, adj_r2=ar2, n=n, T=T, N=int(N))


def panel_ols_fe(df, y_col, x_cols):
    """Panel OLS FE via within-transformation, Newey-West HAC SE."""
    sub = df[["Ticker", y_col] + x_cols].dropna().copy()
    if len(sub) < 50:
        return None
    for col in [y_col] + x_cols:
        sub[col] -= sub.groupby("Ticker")[col].transform("mean")
    y_ = sub[y_col].values
    X_ = np.column_stack([sub[c].values for c in x_cols])
    r  = ols_hac(y_, X_)
    if r is None:
        return None
    r["labels"] = x_cols
    return r


def winsorize_series(s, n_sd):
    s = s.copy()
    valid = s.dropna()
    if len(valid) < 10:
        return s, np.nan, np.nan, 0
    mu, sig = valid.mean(), valid.std()
    lo, hi  = mu - n_sd*sig, mu + n_sd*sig
    nc      = int(((valid < lo) | (valid > hi)).sum())
    return s.clip(lower=lo, upper=hi), lo, hi, nc


def jarque_bera(s):
    s = pd.Series(s).dropna().values
    if len(s) < 8:
        return np.nan, np.nan
    jb = len(s)/6 * (st.skew(s)**2 + st.kurtosis(s)**2/4)
    return round(float(jb), 3), round(float(st.chi2.sf(jb, 2)), 4)


def chow_test(df_pre, df_post, y_col, x_cols):
    """Chow (1960) structural break test."""
    def _fit(d):
        d2 = d[[y_col] + x_cols].dropna()
        if len(d2) < len(x_cols)+5:
            return None
        return ols_hac(d2[y_col].values,
                       np.column_stack([np.ones(len(d2))] +
                                       [d2[c].values for c in x_cols]))
    rp = _fit(pd.concat([df_pre, df_post], ignore_index=True))
    r1 = _fit(df_pre)
    r2 = _fit(df_post)
    if any(r is None for r in [rp, r1, r2]):
        return np.nan, np.nan
    k = len(x_cols)+1
    n = r1["n"] + r2["n"]
    denom = r1["rss"] + r2["rss"]
    if denom < 1e-20 or n-2*k < 1:
        return np.nan, np.nan
    F = ((rp["rss"] - denom)/k) / (denom/(n - 2*k))
    p = float(st.f.sf(max(0.0, F), k, n - 2*k))
    return round(F, 4), round(p, 4)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 2: HAR-RV MODEL  (Corsi 2009)  — NEW 4
# ═══════════════════════════════════════════════════════════════════════

def build_har_features(sub, rv_col="Weekly_Volatility"):
    s  = sub[rv_col].copy()
    df = pd.DataFrame({"RV_t": s})
    df["RV_D"] = s.shift(1)
    df["RV_W"] = s.shift(1).rolling(HAR_LAGS_W,  min_periods=2).mean()
    df["RV_M"] = s.shift(1).rolling(HAR_LAGS_M,  min_periods=4).mean()
    df["ASVI_L1"] = sub["ASVI"].shift(1) if "ASVI" in sub.columns else np.nan
    return df.dropna()


def run_har_rv(df):
    """
    NEW 4: HAR-RV and HAR-RV-ASVI per company.
    HAR-RV:      RV_t = α + β_D·RV(t-1) + β_W·RV_W + β_M·RV_M + ε
    HAR-RV-ASVI: same + γ·ASVI(t-1)
    """
    section("HAR-RV MODELS  [Corsi 2009]")
    log("HAR-RV:      RV_t = α + β_D·RV(t-1) + β_W·RV_W(4wk) + β_M·RV_M(13wk)")
    log("HAR-RV-ASVI: same + γ·ASVI(t-1)\n")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub = df[df["Ticker"]==t].sort_values("Week").copy()
        har = build_har_features(sub)
        if len(har) < MIN_OBS:
            continue
        for (mod_id, use_asvi) in [("HAR_RV", False), ("HAR_RV_ASVI", True)]:
            x_cols = ["RV_D", "RV_W", "RV_M"]
            if use_asvi:
                x_cols += ["ASVI_L1"]
            data = har[["RV_t"] + x_cols].dropna()
            if len(data) < MIN_OBS:
                continue
            y_ = data["RV_t"].values
            X_ = np.column_stack([np.ones(len(data))] +
                                  [data[c].values for c in x_cols])
            r  = ols_hac(y_, X_)
            if r is None:
                continue
            labs = ["Intercept", "β_D", "β_W", "β_M"]
            if use_asvi:
                labs += ["γ_ASVI"]
            for i, lab in enumerate(labs):
                rows.append({
                    "Ticker": t, "Sector": sub["Sector"].iloc[0],
                    "Model": mod_id, "Variable": lab,
                    "Coef": round(float(r["coef"][i]), 6),
                    "SE_HAC": round(float(r["se"][i]), 6),
                    "T_stat": round(float(r["t"][i]), 4),
                    "P_value": round(float(r["p"][i]), 4),
                    "Sig": sig_stars(r["p"][i]),
                    "R2": round(r["r2"], 4),
                    "Adj_R2": round(r["adj_r2"], 4),
                    "N": r["n"],
                })
            if use_asvi:
                asvi_p = r["p"][-1]
                log(f"  {t} HAR-ASVI γ={r['coef'][-1]:+.5f} "
                    f"p={asvi_p:.3f}{sig_stars(asvi_p):<3} "
                    f"R²={r['r2']:.3f} N={r['n']}")
    har_df = pd.DataFrame(rows)
    if not har_df.empty:
        for mod in ["HAR_RV", "HAR_RV_ASVI"]:
            sub_m = har_df[har_df["Model"] == mod]
            mean_r2 = sub_m.groupby("Ticker")["R2"].max().mean()
            log(f"\n  {mod} mean R²={mean_r2:.4f}", "OK")
    return har_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 3: GARCH(1,1) + ASVI IN VARIANCE  — NEW 5
# ═══════════════════════════════════════════════════════════════════════

def _garch_loglik(params, returns, asvi_lag=None):
    """Negative log-likelihood for GARCH(1,1) [+ ASVI in variance]."""
    if asvi_lag is not None and len(params) == 4:
        omega, alpha, beta, delta = params
    elif len(params) == 3:
        omega, alpha, beta = params
        delta = 0.0
    else:
        return 1e10
    if omega <= 0 or alpha < 0 or beta < 0 or alpha+beta >= 1:
        return 1e10
    n = len(returns)
    sigma2 = np.full(n, returns.var())
    ll = 0.0
    for t in range(1, n):
        asvi_t = (float(asvi_lag[t-1])
                  if asvi_lag is not None and not np.isnan(asvi_lag[t-1])
                  else 0.0)
        sigma2[t] = (omega + alpha*returns[t-1]**2 +
                     beta*sigma2[t-1] + max(0.0, delta*asvi_t))
        if sigma2[t] <= 0:
            sigma2[t] = 1e-10
        ll += -0.5*(np.log(2*np.pi) + np.log(sigma2[t]) +
                    returns[t]**2/sigma2[t])
    return -ll


def _numerical_hessian(f, x0, *args, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(i, n):
            xi   = x0.copy(); xi[i] += eps;   xi[j] += eps
            xj_i = x0.copy(); xj_i[i] += eps; xj_i[j] -= eps
            xi_j = x0.copy(); xi_j[i] -= eps; xi_j[j] += eps
            xij  = x0.copy(); xij[i]  -= eps; xij[j]  -= eps
            d2 = (f(xi, *args) - f(xj_i, *args) -
                  f(xi_j, *args) + f(xij, *args)) / (4*eps**2)
            H[i, j] = H[j, i] = d2
    return H


def fit_garch(returns, asvi_lag=None):
    """NEW 5: Fit GARCH(1,1) or GARCH-ASVI via MLE (L-BFGS-B)."""
    r = np.asarray(returns, dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < MIN_OBS:
        return None
    v0 = r.var()
    if asvi_lag is not None:
        a_l = np.asarray(asvi_lag, dtype=float)
        a_l = np.where(np.isfinite(a_l), a_l, 0.0)
        if len(a_l) > len(r):   a_l = a_l[:len(r)]
        elif len(a_l) < len(r): a_l = np.pad(a_l, (len(r)-len(a_l), 0))
        x0  = [v0*0.05, 0.10, 0.85, 0.0001]
        bds = [(1e-8,None),(1e-6,0.499),(1e-6,0.999),(-0.1,0.5)]
        res = minimize(_garch_loglik, x0, args=(r, a_l),
                       bounds=bds, method="L-BFGS-B",
                       options={"ftol":1e-12,"gtol":1e-8,"maxiter":2000})
        labs = ["omega","alpha","beta","delta_asvi"]
    else:
        x0  = [v0*0.05, 0.10, 0.85]
        bds = [(1e-8,None),(1e-6,0.499),(1e-6,0.999)]
        res = minimize(_garch_loglik, x0, args=(r, None),
                       bounds=bds, method="L-BFGS-B",
                       options={"ftol":1e-12,"gtol":1e-8,"maxiter":2000})
        labs = ["omega","alpha","beta"]
    if not res.success and res.fun > 1e9:
        return None
    p  = res.x
    n  = len(r)
    k  = len(p)
    ll = -res.fun
    try:
        H  = _numerical_hessian(_garch_loglik, p, r, asvi_lag)
        se = np.sqrt(np.maximum(np.diag(np.linalg.pinv(H)), 0))
    except Exception:
        se = np.full(k, np.nan)
    t_  = np.where(se > 1e-20, p/se, np.nan)
    pv  = 2 * st.norm.sf(np.abs(t_))
    aic = -2*ll + 2*k
    bic = -2*ll + k*np.log(n)
    return dict(params=p, se=se, t=t_, p=pv, labels=labs,
                loglik=round(ll,2), aic=round(aic,2), bic=round(bic,2),
                n=n, persistence=round(float(p[1]+p[2]),4))


def run_garch(df):
    """NEW 5: GARCH(1,1) and GARCH-ASVI per company."""
    section("GARCH(1,1) AND GARCH-ASVI MODELS  [NEW 5]")
    log("GARCH(1,1):  σ²_t = ω + α·ε²_{t-1} + β·σ²_{t-1}")
    log("GARCH-ASVI:  σ²_t = ω + α·ε²_{t-1} + β·σ²_{t-1} + δ·ASVI_{t-1}")
    log("MLE via L-BFGS-B  |  SE via numerical Hessian\n")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub  = df[df["Ticker"]==t].sort_values("Week")
        rets = sub["Weekly_Return"].dropna().values
        asvi = sub["ASVI_L1"].values[:len(rets)]
        for (mod_id, use_asvi) in [("GARCH11", False), ("GARCH_ASVI", True)]:
            g = fit_garch(rets, asvi_lag=(asvi if use_asvi else None))
            if g is None:
                continue
            for i, lab in enumerate(g["labels"]):
                rows.append({
                    "Ticker": t, "Sector": sub["Sector"].iloc[0],
                    "Model": mod_id, "Param": lab,
                    "Estimate": round(float(g["params"][i]), 6),
                    "SE": round(float(g["se"][i]), 6) if not np.isnan(g["se"][i]) else np.nan,
                    "T_stat": round(float(g["t"][i]), 4) if not np.isnan(g["t"][i]) else np.nan,
                    "P_value": round(float(g["p"][i]), 4) if not np.isnan(g["p"][i]) else np.nan,
                    "Sig": sig_stars(g["p"][i]),
                    "LogLik": g["loglik"], "AIC": g["aic"], "BIC": g["bic"],
                    "Persistence": g["persistence"], "N": g["n"],
                })
            if use_asvi:
                delta_p = float(g["p"][-1])
                log(f"  {t} δ(ASVI)={g['params'][-1]:+.6f} "
                    f"p={delta_p:.3f}{sig_stars(delta_p):<3} "
                    f"persist={g['persistence']:.3f}")
    garch_df = pd.DataFrame(rows)
    if not garch_df.empty:
        n_sig = (garch_df[(garch_df["Model"]=="GARCH_ASVI") &
                          (garch_df["Param"]=="delta_asvi")]["P_value"] < 0.05).sum()
        n_co  = (garch_df["Model"]=="GARCH_ASVI").any()
        log(f"\n  GARCH-ASVI δ significant @5%: {n_sig} companies", "OK")
    return garch_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 4: QUANTILE REGRESSION  — NEW 9
# ═══════════════════════════════════════════════════════════════════════

def quantile_reg(y, X, tau):
    """
    NEW 9: Quantile regression via LP (Koenker & Bassett 1978).
    Variables: [β⁺(k), β⁻(k), u⁺(n), u⁻(n)]
    """
    mask = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    y_, X_ = y[mask], X[mask]
    n, k = X_.shape
    if n < k + 10:
        return None
    c   = np.concatenate([np.zeros(2*k), tau*np.ones(n), (1-tau)*np.ones(n)])
    Aeq = np.hstack([X_, -X_, np.eye(n), -np.eye(n)])
    beq = y_
    bds = [(0, None)] * (2*k + 2*n)
    res = linprog(c, A_eq=Aeq, b_eq=beq, bounds=bds,
                  method="highs", options={"disp": False})
    if res.status != 0:
        return None
    x   = res.x
    b   = x[:k] - x[k:2*k]
    resid = y_ - X_ @ b
    def _check(u, tau): return np.sum(np.where(u >= 0, tau*u, (tau-1)*u))
    rho_u = _check(resid, tau)
    rho_r = _check(y_ - np.quantile(y_, tau), tau)
    r1 = 1 - rho_u/rho_r if rho_r > 1e-15 else np.nan
    return dict(coef=b, resid=resid, pseudo_r2=round(float(r1), 4),
                n=int(mask.sum()))


def run_quantile_regressions(df):
    """NEW 9: Quantile regression at τ=0.25/0.50/0.75/0.90."""
    section("QUANTILE REGRESSIONS  [NEW 9]")
    log("Model: Q_τ[Vol(t)] = α + ASVI(t-1) + Vol(t-1) + Crisis\n")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub   = df[df["Ticker"]==t].sort_values("Week")
        x_cols = ["ASVI_L1", "Weekly_Volatility_L1", "crisis"]
        data  = sub[["Weekly_Volatility"] + x_cols].dropna()
        if len(data) < MIN_OBS:
            continue
        y_ = data["Weekly_Volatility"].values
        X_ = np.column_stack([np.ones(len(data))] +
                              [data[c].values for c in x_cols])
        for tau in QUANTILE_TAUS:
            r = quantile_reg(y_, X_, tau)
            if r is None:
                continue
            labs = ["Intercept", "ASVI(t-1)", "Vol(t-1)", "Crisis"]
            for i, lab in enumerate(labs):
                rows.append({
                    "Ticker": t, "Sector": sub["Sector"].iloc[0],
                    "Tau": tau, "Variable": lab,
                    "Coef": round(float(r["coef"][i]), 6),
                    "Pseudo_R2": r["pseudo_r2"], "N": r["n"],
                })
        r75 = quantile_reg(y_, X_, 0.75)
        if r75 and len(r75["coef"]) > 1:
            log(f"  {t} τ=0.75 ASVI={r75['coef'][1]:+.5f} "
                f"PseudoR²={r75['pseudo_r2']:.3f} N={r75['n']}")
    qr_df = pd.DataFrame(rows)
    if not qr_df.empty:
        for tau in QUANTILE_TAUS:
            sub_t = qr_df[(qr_df["Tau"]==tau) & (qr_df["Variable"]=="ASVI(t-1)")]
            mb  = sub_t["Coef"].mean()
            np_ = (sub_t["Coef"] > 0).sum()
            log(f"\n  τ={tau:.2f} mean ASVI={mb:+.5f} {np_}/{len(sub_t)} positive", "OK")
    return qr_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 5: EVENT STUDY  — NEW 10
# ═══════════════════════════════════════════════════════════════════════

def run_event_study(df, threshold_sd=1.5, window=4):
    """NEW 10: Event study around ASVI spikes (±window weeks)."""
    section(f"EVENT STUDY: ASVI SPIKES  [NEW 10]  (threshold={threshold_sd}σ, ±{window}wk)")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub     = df[df["Ticker"]==t].sort_values("Week").reset_index(drop=True)
        mu_asvi = sub["ASVI"].mean()
        sd_asvi = sub["ASVI"].std()
        thresh  = mu_asvi + threshold_sd * sd_asvi
        normal  = sub[sub["crisis"]==0]
        mu_ret  = normal["Weekly_Return"].mean()
        mu_vol  = normal["Weekly_Volatility"].mean()
        events  = sub[sub["ASVI"] > thresh].index.tolist()
        log(f"  {t}: {len(events)} spike events (>{thresh:.3f})")
        for ev_idx in events:
            for idx in range(max(0, ev_idx-window), min(len(sub), ev_idx+window+1)):
                rel = idx - ev_idx
                ret = sub.loc[idx, "Weekly_Return"]
                vol = sub.loc[idx, "Weekly_Volatility"]
                rows.append({
                    "Ticker": t, "Sector": sub["Sector"].iloc[0],
                    "Event_Week": sub.loc[ev_idx, "Week"],
                    "ASVI_Event": round(float(sub.loc[ev_idx, "ASVI"]), 4),
                    "Relative_t": rel,
                    "Return": ret,
                    "Abnormal_Return": ret - mu_ret if not np.isnan(ret) else np.nan,
                    "Volatility": vol,
                    "Abnormal_Volatility": vol - mu_vol if not np.isnan(vol) else np.nan,
                })
    ev_df = pd.DataFrame(rows)
    if ev_df.empty:
        log("  No events found.", "WARN")
        return ev_df
    log(f"\n  {'t':>4}  {'CAAR':>10}  {'CAAV':>10}  {'N':>5}")
    log("  " + "─"*32)
    for rel_t in sorted(ev_df["Relative_t"].unique()):
        s_t  = ev_df[ev_df["Relative_t"]==rel_t]
        caar = float(s_t["Abnormal_Return"].mean())
        caav = float(s_t["Abnormal_Volatility"].mean())
        n_   = int(s_t["Abnormal_Return"].notna().sum())
        log(f"  {rel_t:>4}  {caar:>+10.5f}  {caav:>+10.5f}  {n_:>5}")
    log(f"\n  Total events: {len(events)} across {ev_df['Ticker'].nunique()} firms", "OK")
    return ev_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 6: PRE-TREND ANALYSIS  — NEW 11
# ═══════════════════════════════════════════════════════════════════════

def run_pretrend_analysis(df):
    """NEW 11: Pre-2022 rolling 52-week ASVI→Vol correlation trend."""
    section("PRE-TREND ANALYSIS  [NEW 11]  (52-wk rolling corr, pre-2022)")
    df_pre = df[df["Week"] < BREAK_2022_START].copy()
    rows   = []
    for t in sorted(df["Ticker"].unique()):
        sub  = df_pre[df_pre["Ticker"]==t].sort_values("Week")
        data = sub[["ASVI_L1", "Weekly_Volatility"]].dropna()
        if len(data) < 60:
            continue
        ts = data.copy()
        ts.index = sub.loc[data.index, "Week"]
        rc_raw = ts.rolling(52, min_periods=26).corr()
        if isinstance(rc_raw.index, pd.MultiIndex):
            rc_s = rc_raw.xs("ASVI_L1", level=1)["Weekly_Volatility"].dropna()
        else:
            continue
        if len(rc_s) < 10:
            continue
        x_trend   = np.arange(len(rc_s))
        r_trend   = float(np.corrcoef(x_trend, rc_s.values)[0, 1])
        _, p_mk   = st.kendalltau(x_trend, rc_s.values)
        rows.append({
            "Ticker": t, "Sector": sub["Sector"].iloc[0],
            "r_trend": round(r_trend, 4),
            "p_mannkendall": round(float(p_mk), 4),
            "mean_corr": round(float(rc_s.mean()), 4),
            "std_corr": round(float(rc_s.std()), 4),
        })
        log(f"  {t}: mean_r={rows[-1]['mean_corr']:+.3f} "
            f"trend_r={r_trend:+.3f} MK_p={p_mk:.3f} "
            f"{'[TRENDING]' if p_mk < 0.10 else '[stable]'}")
    pt_df = pd.DataFrame(rows)
    if not pt_df.empty:
        n_t = (pt_df["p_mannkendall"] < 0.10).sum()
        log(f"\n  {n_t}/{len(pt_df)} firms trending in pre-crisis corr (MK p<0.10)", "OK")
    return pt_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 7: POWER / MDE ANALYSIS  — NEW 12
# ═══════════════════════════════════════════════════════════════════════

def run_power_analysis(df, reg_df):
    """NEW 12: Post-hoc power & MDE analysis using non-central t distribution."""
    section("POWER AND MDE ANALYSIS  [NEW 12]")
    log(f"Target: 80% power, α={ALPHA}  (non-central t, two-sided)\n")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub   = df[df["Ticker"]==t].sort_values("Week")
        x_cols = ["ASVI_L1", "Weekly_Volatility_L1", "crisis"]
        data  = sub[["Weekly_Volatility"] + x_cols].dropna()
        if len(data) < MIN_OBS:
            continue
        y_ = data["Weekly_Volatility"].values
        X_ = np.column_stack([np.ones(len(data))] +
                              [data[c].values for c in x_cols])
        r  = ols_hac(y_, X_)
        if r is None:
            continue
        N     = r["n"]
        k     = X_.shape[1]
        df_   = N - k
        se_b1 = float(r["se"][1])
        b_obs = float(r["coef"][1])
        t_crit  = st.t.ppf(1 - ALPHA/2, df=df_)
        t_pow   = st.norm.ppf(0.80)
        mde     = (t_crit + t_pow) * se_b1
        ncp     = abs(b_obs) / se_b1 if se_b1 > 1e-20 else 0.0
        power   = float(1 - st.t.cdf(t_crit, df=df_, loc=ncp) +
                        st.t.cdf(-t_crit, df=df_, loc=ncp))
        rows.append({
            "Ticker": t, "Sector": sub["Sector"].iloc[0],
            "N": N, "SE_ASVI": round(se_b1, 6),
            "Beta_ASVI": round(b_obs, 6),
            "MDE_80pct": round(mde, 5),
            "Actual_Power": round(power, 3),
            "Underpowered": (power < 0.80),
        })
        log(f"  {t}: N={N} β={b_obs:+.5f} MDE={mde:+.5f} "
            f"Power={power:.1%} "
            f"{'[UNDERPOWERED]' if power < 0.80 else '[OK]'}")
    pwr_df = pd.DataFrame(rows)
    if not pwr_df.empty:
        n_u = pwr_df["Underpowered"].sum()
        log(f"\n  {n_u}/{len(pwr_df)} firms underpowered (<80%) for observed β(ASVI)", "OK")
    return pwr_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 8: FALSIFICATION TEST  — NEW 13
# ═══════════════════════════════════════════════════════════════════════

def run_falsification(df, n_iter=N_FALSE):
    """NEW 13: Date-shuffled ASVI falsification test."""
    section(f"FALSIFICATION TEST  [NEW 13]  ({n_iter} iter, shuffled ASVI dates)")
    log("H₀: Time-ordering of ASVI is irrelevant (shuffled → same result)\n")
    rng  = np.random.default_rng(SEED+99)
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub    = df[df["Ticker"]==t].sort_values("Week").copy()
        x_cols = ["ASVI_L1", "Weekly_Volatility_L1", "crisis"]
        data   = sub[["Weekly_Volatility"] + x_cols].dropna()
        if len(data) < MIN_OBS:
            continue
        y_ = data["Weekly_Volatility"].values
        X_ = np.column_stack([np.ones(len(data))] +
                              [data[c].values for c in x_cols])
        r0 = ols_hac(y_, X_)
        if r0 is None:
            continue
        b_obs = float(r0["coef"][1])
        asvi_vals = data["ASVI_L1"].values.copy()
        fake_coefs = []
        for _ in range(n_iter):
            shuf = rng.permutation(asvi_vals)
            Xsh  = X_.copy()
            Xsh[:, 1] = shuf
            rsh  = ols_hac(y_, Xsh)
            if rsh is not None:
                fake_coefs.append(float(rsh["coef"][1]))
        if not fake_coefs:
            continue
        fc       = np.array(fake_coefs)
        p_false  = float(np.mean(np.abs(fc) >= abs(b_obs)))
        rows.append({
            "Ticker": t, "Sector": sub["Sector"].iloc[0],
            "Beta_observed": round(b_obs, 6),
            "Beta_shuffle_mean": round(float(fc.mean()), 6),
            "Beta_shuffle_std": round(float(fc.std()), 6),
            "P_false_twosided": round(p_false, 4),
            "Conclusion": ("SPURIOUS" if p_false > 0.10 else "GENUINE"),
        })
        log(f"  {t}: β_obs={b_obs:+.5f} β_shuffle={fc.mean():+.5f}±{fc.std():.5f} "
            f"p_false={p_false:.3f} "
            f"{'[SPURIOUS?]' if p_false > 0.10 else '[GENUINE]'}")
    false_df = pd.DataFrame(rows)
    if not false_df.empty:
        n_g = (false_df["Conclusion"]=="GENUINE").sum()
        log(f"\n  {n_g}/{len(false_df)} firms show genuine ASVI effect (p_false≤0.10)", "OK")
    return false_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 9: LOAD + PREPARE DATA
# ═══════════════════════════════════════════════════════════════════════

def load_and_prepare():
    if not os.path.exists(IN_FILE):
        print(f"\n  ✗  MASTER_DATASET.csv not found: {IN_FILE}")
        sys.exit(1)

    df = pd.read_csv(IN_FILE, encoding="utf-8-sig", low_memory=False)
    df["Week"] = pd.to_datetime(df["Week"], errors="coerce")
    df = df.sort_values(["Ticker", "Week"]).reset_index(drop=True)
    log(f"Loaded: {len(df):,} rows × {len(df.columns)} cols")
    log(f"Companies: {df['Ticker'].nunique()} | "
        f"Date range: {df['Week'].min().date()} → {df['Week'].max().date()}")

    # ── Crisis dummies
    df["crisis"] = (
        (df["Week"] >= BREAK_2022_START - pd.Timedelta(weeks=4)) &
        (df["Week"] <= BREAK_2022_END   + pd.Timedelta(weeks=4))
    ).astype(float)
    df["yndx_break"] = (
        (df["Ticker"]=="YNDX") & (df["Week"] >= BREAK_YNDX_2024)
    ).astype(float)
    # FIX 1 — GAZP Aug-Sep 2022 extraordinary dividend event
    df["gazp_aug22"] = (
        (df["Ticker"]=="GAZP") &
        (df["Week"] >= GAZP_EVENT_START) &
        (df["Week"] <= GAZP_EVENT_END)
    ).astype(float)
    n_gazp = int(df["gazp_aug22"].sum())
    log(f"  GAZP Aug-2022 event dummy: {n_gazp} weeks "
        f"({GAZP_EVENT_START.date()} – {GAZP_EVENT_END.date()})")

    # ── Log volume
    vol_raw = df["Volume"].copy().astype(float)
    vol_raw[vol_raw <= 0] = np.nan
    df["LnVol"] = np.log(vol_raw)

    # ── Winsorisation (per company)
    winsor_log = {}
    df["Ret_w"]  = df["Weekly_Return"].copy()
    df["ASVI_w"] = df["ASVI"].copy()
    for t in df["Ticker"].unique():
        mask = df["Ticker"]==t
        ws, lo, hi, nc = winsorize_series(df.loc[mask, "Weekly_Return"], WINSOR_RET_SD)
        df.loc[mask, "Ret_w"] = ws.values
        winsor_log[t] = {"ret_lo": lo, "ret_hi": hi, "ret_n": nc}
        ws2, lo2, hi2, nc2 = winsorize_series(df.loc[mask, "ASVI"], WINSOR_ASVI_SD)
        df.loc[mask, "ASVI_w"] = ws2.values
        winsor_log[t]["asvi_n"] = nc2

    # ── Lagged variables
    for col in ["ASVI","ASVI_w","Weekly_Volatility","Weekly_Return",
                "Ret_w","LnVol"]:
        df[f"{col}_L1"] = df.groupby("Ticker")[col].shift(1)

    # ── ΔVol
    df["DeltaVol"]    = df.groupby("Ticker")["Weekly_Volatility"].diff()
    df["DeltaVol_L1"] = df.groupby("Ticker")["DeltaVol"].shift(1)

    # ── Sub-period markers
    df["pre_crisis"]  = (df["Week"] < BREAK_2022_START).astype(int)
    df["post_crisis"] = (df["Week"] > BREAK_2022_END).astype(int)

    # ── Volume coverage
    vol_pct = {}
    for t in df["Ticker"].unique():
        sub = df[df["Ticker"]==t]
        vol_pct[t] = sub["LnVol"].notna().mean()*100

    # ── Non-stationary volatility flags (ADF)
    vol_nonstat = set()
    for t in df["Ticker"].unique():
        s = df[df["Ticker"]==t]["Weekly_Volatility"].dropna()
        if len(s) < 25: continue
        _, p, _ = adf_test(s)
        if not np.isnan(p) and p >= 0.05:
            vol_nonstat.add(t)
            log(f"  {t}: Vol ADF p={p:.3f} ≥ 0.05 → non-stationary → M1d", "WARN")

    df["_vol_nonstat"] = df["Ticker"].isin(vol_nonstat).astype(int)
    df["_use_lnvol"]   = df.apply(
        lambda r: (vol_pct.get(r["Ticker"], 0) >= 60 and
                   r["Ticker"] not in INDEX_TICKERS), axis=1).astype(int)

    _MANIFEST["summaries"]["n_obs"]       = len(df)
    _MANIFEST["summaries"]["n_companies"] = int(df["Ticker"].nunique())
    _MANIFEST["summaries"]["vol_nonstat"] = sorted(vol_nonstat)

    return df, winsor_log, vol_pct, vol_nonstat


# ═══════════════════════════════════════════════════════════════════════
# SECTION 10: DATA QUALITY AUDIT
# ═══════════════════════════════════════════════════════════════════════

def data_quality_audit(df, winsor_log):
    section("DATA QUALITY AUDIT")
    tickers = sorted(df["Ticker"].unique())
    issues  = []
    qdata   = {}

    # Coverage
    cov_rows = []
    log(f"  {'Ticker':<6} {'Sector':<14} {'N':>4}  "
        f"{'Close':>8}{'Return':>8}{'Vol':>7}{'ASVI':>7}{'LnVol':>7}")
    log("  " + "─"*58)
    for t in tickers:
        sub = df[df["Ticker"]==t]
        row = {"Ticker": t, "Sector": sub["Sector"].iloc[0], "N": len(sub)}
        for c in ["Close","Weekly_Return","Weekly_Volatility","ASVI","LnVol"]:
            if c in sub.columns:
                pct = sub[c].notna().mean()*100
            else:
                pct = 0.0
            row[f"{c}_pct"] = round(pct, 2)
        cov_rows.append(row)
        log(f"  {t:<6} {row['Sector']:<14} {row['N']:>4}  "
            f"{row.get('Close_pct',0):>7.1f}%"
            f"{row.get('Weekly_Return_pct',0):>7.1f}%"
            f"{row.get('Weekly_Volatility_pct',0):>6.1f}%"
            f"{row.get('ASVI_pct',0):>6.1f}%"
            f"{row.get('LnVol_pct',0):>6.1f}%")
    qdata["coverage"] = pd.DataFrame(cov_rows)

    # Extreme returns
    log("\nExtreme return events (|ret| > 35%):")
    ext_rows = []
    for t in tickers:
        sub = df[df["Ticker"]==t]
        if "Weekly_Return" not in sub.columns: continue
        ext = sub[sub["Weekly_Return"].abs() > 0.35]
        for _, row in ext.iterrows():
            in_crisis = (BREAK_2022_START - pd.Timedelta(weeks=2) <=
                         row["Week"] <= BREAK_2022_END + pd.Timedelta(weeks=6))
            in_gazp   = (t=="GAZP" and
                         GAZP_EVENT_START <= row["Week"] <= GAZP_EVENT_END)
            if in_gazp:
                explanation = "GAZP Aug-2022 div event → gazp_aug22 dummy"
            elif in_crisis:
                explanation = "MOEX reopening — expected, crisis dummy covers"
            else:
                explanation = "INVESTIGATE — unexpected extreme return"
                issues.append(f"CRITICAL: {t} extreme {row['Weekly_Return']*100:.1f}% "
                               f"on {row['Week'].date()}")
            ext_rows.append({"Ticker": t, "Week": row["Week"].date(),
                              "Return_pct": f"{row['Weekly_Return']*100:.1f}%",
                              "Explanation": explanation})
            level = "OK" if (in_crisis or in_gazp) else "WARN"
            log(f"  {t}: {row['Weekly_Return']*100:.1f}% on "
                f"{row['Week'].date()} → {explanation}", level)
    qdata["extreme_returns"] = pd.DataFrame(ext_rows)

    # Stationarity
    log("\nStationarity (ADF, MacKinnon 1994):")
    stat_rows = []
    for t in tickers:
        sub = df[df["Ticker"]==t]
        for col in ["Weekly_Return","Weekly_Volatility","ASVI","LnVol"]:
            if col not in sub.columns: continue
            s = sub[col].dropna()
            if len(s) < 25: continue
            adf, p, lags = adf_test(s)
            is_stat = not np.isnan(p) and p < 0.05
            stat_rows.append({"Ticker": t, "Variable": col,
                               "ADF": adf, "ADF_p": p, "Lags": lags,
                               "Stationary": "YES" if is_stat else "NO"})
    stat_df = pd.DataFrame(stat_rows)
    for col in ["Weekly_Return","Weekly_Volatility","ASVI"]:
        sub_s = stat_df[stat_df["Variable"]==col]
        non_s = sub_s[sub_s["Stationary"]=="NO"]["Ticker"].tolist()
        if non_s:
            log(f"  {col}: non-stationary {non_s}", "WARN")
        else:
            log(f"  {col}: all stationary ✓", "OK")
    qdata["stationarity"] = stat_df

    issues += [
        "ALL: 2022 MOEX closure → crisis dummy ±4 wks",
        "YNDX: Jul 2024 restructure → yndx_break dummy",
        "TCSG: shorter sample (IPO Nov 2019) — ~25% lower power",
        "MOEX: market index — LnVol excluded",
        "GAZP: Aug-Sep 2022 dividend event — gazp_aug22 dummy (FIX 1)",
    ]
    qdata["issues"] = issues
    n_crit = sum(1 for i in issues if "CRITICAL" in i)
    log(f"\n  Issues: {len(issues)} | Critical: {n_crit}")
    if n_crit == 0:
        log("  No critical data errors ✓", "OK")
    return qdata


# ═══════════════════════════════════════════════════════════════════════
# SECTION 11: DESCRIPTIVE STATISTICS
# ═══════════════════════════════════════════════════════════════════════

def descriptive_stats(df):
    section("DESCRIPTIVE STATISTICS")
    vars_map = {
        "Close": "Closing Price (RUB)",
        "Weekly_Return": "Weekly Return",
        "Weekly_Volatility": "Realized Volatility",
        "ASVI": "ASVI",
    }
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub = df[df["Ticker"]==t]
        for col, label in vars_map.items():
            if col not in sub.columns: continue
            s = sub[col].dropna()
            if len(s) < 5: continue
            jb, jbp       = jarque_bera(s)
            adf, adfp, _  = adf_test(s)
            rows.append({
                "Ticker": t, "Company": sub.get("Company", pd.Series([t])).iloc[0],
                "Sector": sub["Sector"].iloc[0], "Variable": label, "N": len(s),
                "Mean": round(float(s.mean()), 6),
                "Std":  round(float(s.std()), 6),
                "Min":  round(float(s.min()), 6),
                "P25":  round(float(s.quantile(0.25)), 6),
                "Median": round(float(s.median()), 6),
                "P75":  round(float(s.quantile(0.75)), 6),
                "Max":  round(float(s.max()), 6),
                "Skewness": round(float(st.skew(s)), 4),
                "Kurtosis_excess": round(float(st.kurtosis(s)), 4),
                "JB_stat": jb, "JB_p": jbp,
                "ADF_stat": adf, "ADF_p": adfp,
                "I0_5pct": "YES" if (not np.isnan(adfp) and adfp < 0.05) else "NO",
                "Normal_5pct": "NO" if (not np.isnan(jbp) and jbp < 0.05) else "YES",
            })
    desc = pd.DataFrame(rows)
    log(f"  {'Ticker':<6} {'Mean':>9} {'Std':>8} {'Skew':>7} {'Kurt':>8} I(0) Normal")
    for _,r in desc[desc["Variable"]=="Weekly Return"].iterrows():
        log(f"  {r['Ticker']:<6} {r['Mean']:>+9.5f} {r['Std']:>8.5f} "
            f"{r['Skewness']:>7.3f} {r['Kurtosis_excess']:>8.3f}  "
            f"{r['I0_5pct']:<4} {r['Normal_5pct']}")
    return desc


# ═══════════════════════════════════════════════════════════════════════
# SECTION 12: GRANGER CAUSALITY  (NEW 3,7)
# ═══════════════════════════════════════════════════════════════════════

def granger_analysis(df):
    section("GRANGER CAUSALITY  [parametric + permutation + BH-FDR]")
    log("H₀: X does NOT Granger-cause Y  |  lags 1,2,4\n")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub = df[df["Ticker"]==t].sort_values("Week")
        for (xcol, ycol, h) in [
            ("ASVI",    "Weekly_Volatility", "H1: ASVI→Vol"),
            ("ASVI",    "Weekly_Return",     "H2: ASVI→Ret"),
            ("ASVI_w",  "Weekly_Volatility", "H1w: ASVI_win→Vol"),
        ]:
            v = sub[[xcol, ycol]].dropna()
            gc = granger_test(v[ycol], v[xcol])
            for lag, (F, p) in gc.items():
                rows.append({
                    "Ticker": t, "Sector": sub["Sector"].iloc[0],
                    "Hypothesis": h, "X": xcol, "Y": ycol, "Lag": lag,
                    "F_stat": round(F, 4) if not np.isnan(F) else np.nan,
                    "P_param": round(p, 4) if not np.isnan(p) else np.nan,
                    "P_perm": np.nan, "Sig_param": sig_stars(p), "N": len(v),
                })

    gc_df = pd.DataFrame(rows)

    # NEW 7: Permutation Granger for H1 lag=1
    log("\n  Running permutation Granger tests (H1, lag=1) …")
    for t in sorted(df["Ticker"].unique()):
        sub = df[df["Ticker"]==t].sort_values("Week")
        v   = sub[["ASVI","Weekly_Volatility"]].dropna()
        F_obs, p_perm, p_par = permutation_granger(
            v["Weekly_Volatility"].values, v["ASVI"].values,
            n_perm=N_PERM, lag=1)
        mask = ((gc_df["Ticker"]==t) &
                (gc_df["Hypothesis"]=="H1: ASVI→Vol") &
                (gc_df["Lag"]==1))
        if mask.any():
            gc_df.loc[mask, "P_perm"] = p_perm
            log(f"  {t} F={F_obs:.3f} p_par={p_par:.3f} p_perm={p_perm:.3f}"
                if not np.isnan(F_obs) else f"  {t}: NaN (model instability)")

    # NEW 3: BH-FDR on H1 lag=1
    h1_mask = (gc_df["Hypothesis"]=="H1: ASVI→Vol") & (gc_df["Lag"]==1)
    pv = gc_df.loc[h1_mask, "P_param"].values
    gc_df.loc[h1_mask, "P_BH"] = bh_fdr(pv)
    gc_df["Sig_BH"] = gc_df.get("P_BH", pd.Series(
        np.nan, index=gc_df.index)).apply(
        lambda p: sig_stars(p) if not (isinstance(p, float) and np.isnan(p)) else "")

    # Summary
    for h in ["H1: ASVI→Vol","H2: ASVI→Ret"]:
        sm   = gc_df[(gc_df["Hypothesis"]==h) & (gc_df["Lag"]==1)]
        n5   = (sm["P_param"] < 0.05).sum()
        n10  = (sm["P_param"] < 0.10).sum()
        sigs = list(sm[sm["P_param"] < 0.05]["Ticker"])
        log(f"\n  {h} @lag=1: {n5}/15 sig @5% ({n10} @10%) {sigs}", "OK")
    n_bh = (gc_df.loc[h1_mask, "P_BH"] < 0.05).sum() if "P_BH" in gc_df.columns else 0
    log(f"\n  H1 after BH-FDR: {n_bh} sig @5%", "OK")

    return gc_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 13: OLS REGRESSIONS  (NEW 3,8,FIX 1,14)
# ═══════════════════════════════════════════════════════════════════════

def _smart_reg(sub, y_col, x_preferred, ticker):
    notes  = []
    x_full = x_preferred[:]
    if ticker in INDEX_TICKERS and "LnVol_L1" in x_full:
        x_full.remove("LnVol_L1")
        notes.append(f"{ticker} INDEX → LnVol_L1 excluded")
    n_full = sub[[y_col]+x_full].dropna().__len__()
    x_base = [c for c in x_full if c != "LnVol_L1"]
    n_base = sub[[y_col]+x_base].dropna().__len__()
    if (n_base > 0 and n_full < n_base*(1-LNVOL_DROP_PCT)
            and "LnVol_L1" in x_full):
        x_full = x_base[:]
        notes.append("LnVol_L1 dropped (>30% sample loss)")
    data = sub[[y_col]+x_full].dropna()
    if len(data) < MIN_OBS:
        notes.append(f"Insufficient obs N={len(data)}")
        return None, x_full, notes
    y_ = data[y_col].values
    X_ = np.column_stack([np.ones(len(data))] +
                          [data[c].values for c in x_full])
    r  = ols_hac(y_, X_)
    if r is None:
        notes.append("OLS failed")
        return None, x_full, notes
    return r, x_full, notes


def run_regressions(df):
    """OLS M1/M2 + block-bootstrap CI + BH-FDR + GAZP dummy + ΔVol."""
    section("OLS REGRESSIONS  [FIX 1,2 | NEW 3,8,14]")
    log("M1:  Vol(t)=α+ASVI(t-1)+Vol(t-1)+[LnVol(t-1)]+Crisis[+dummies]")
    log("M2:  Ret(t)=α+ASVI(t-1)+Ret(t-1)+Vol(t-1)+Crisis")
    log("M1r/M2r: winsorised ASVI | M1d: ΔVol for non-stationary Vol\n")

    LAB_MAP = {
        "ASVI_L1":              "ASVI(t-1)",
        "ASVI_w_L1":            "ASVI_win(t-1)",
        "Weekly_Volatility_L1": "Vol(t-1)",
        "Weekly_Return_L1":     "Ret(t-1)",
        "DeltaVol_L1":          "ΔVol(t-1)",
        "LnVol_L1":             "LnVol(t-1)",
        "crisis":               "Crisis_2022",
        "yndx_break":           "YNDX_Break_2024",
        "gazp_aug22":           "GAZP_Aug22",
    }
    rows      = []
    boot_rows = []

    for t in sorted(df["Ticker"].unique()):
        sub     = df[df["Ticker"]==t].sort_values("Week").copy()
        vnstat  = bool(sub["_vol_nonstat"].iloc[0])

        def _extras():
            ex = ["crisis"]
            if t == "YNDX": ex.append("yndx_break")
            if t == "GAZP": ex.append("gazp_aug22")   # FIX 1
            return ex

        for (mod_id, y_col, asvi_col) in [
            ("M1",  "Weekly_Volatility", "ASVI_L1"),
            ("M1r", "Weekly_Volatility", "ASVI_w_L1"),
            ("M2",  "Weekly_Return",     "ASVI_L1"),
            ("M2r", "Weekly_Return",     "ASVI_w_L1"),
        ]:
            if "Volatility" in y_col:
                others = ["Weekly_Volatility_L1", "LnVol_L1"]
            else:
                others = ["Weekly_Return_L1", "Weekly_Volatility_L1"]
            x_pref = [asvi_col] + others + _extras()
            r, x_used, notes = _smart_reg(sub, y_col, x_pref, t)
            for n in notes:
                log(f"  {t} {mod_id}: {n}", "WARN")
            if r is None:
                continue
            var_labs = ["Intercept"] + [LAB_MAP.get(x, x) for x in x_used]
            for i, lab in enumerate(var_labs):
                rows.append({
                    "Ticker": t, "Sector": sub["Sector"].iloc[0],
                    "Model": mod_id, "Variable": lab,
                    "Coef": round(float(r["coef"][i]), 6),
                    "SE_HAC": round(float(r["se"][i]), 6),
                    "T_stat": round(float(r["t"][i]), 4),
                    "P_value": round(float(r["p"][i]), 4),
                    "Sig": sig_stars(r["p"][i]),
                    "R2": round(r["r2"], 4),
                    "Adj_R2": round(r["adj_r2"], 4),
                    "N": r["n"],
                    "LnVol_included": ("LnVol_L1" in x_used),
                })
            if mod_id == "M1":
                log(f"  {t} M1 β(ASVI)={r['coef'][1]:>+8.5f} "
                    f"p={r['p'][1]:.3f}{sig_stars(r['p'][1]):<3} "
                    f"R²={r['adj_r2']:.3f} N={r['n']}")

            # NEW 8: Block bootstrap CI (M1/M2 only)
            if mod_id in ("M1", "M2"):
                data = sub[[y_col]+x_used].dropna()
                if len(data) >= MIN_OBS:
                    y_arr = data[y_col].values
                    X_arr = np.column_stack([np.ones(len(data))] +
                                            [data[c].values for c in x_used])
                    bc = block_bootstrap_ci({"y": y_arr, "X": X_arr},
                                            n_boot=N_BOOT)
                    if bc:
                        boot_rows.append({
                            "Ticker": t, "Model": mod_id,
                            "Boot_CI_lo": bc[0], "Boot_CI_hi": bc[1],
                            "Boot_mean": bc[2], "Boot_std": bc[3],
                        })

        # NEW 14: M1d for non-stationary volatility (AFLT)
        if vnstat:
            x_pref = ["ASVI_L1", "DeltaVol_L1", "crisis"]
            r, x_used, _ = _smart_reg(sub, "DeltaVol", x_pref, t)
            if r:
                for i, lab in enumerate(
                        ["Intercept"] + [LAB_MAP.get(x, x) for x in x_used]):
                    rows.append({
                        "Ticker": t, "Sector": sub["Sector"].iloc[0],
                        "Model": "M1d", "Variable": lab,
                        "Coef": round(float(r["coef"][i]), 6),
                        "SE_HAC": round(float(r["se"][i]), 6),
                        "T_stat": round(float(r["t"][i]), 4),
                        "P_value": round(float(r["p"][i]), 4),
                        "Sig": sig_stars(r["p"][i]),
                        "R2": round(r["r2"], 4),
                        "Adj_R2": round(r["adj_r2"], 4),
                        "N": r["n"], "LnVol_included": False,
                    })

    reg_df  = pd.DataFrame(rows)
    boot_df = pd.DataFrame(boot_rows)

    # NEW 3: BH-FDR
    for mod in ["M1","M2"]:
        av   = "ASVI(t-1)"
        mask = (reg_df["Model"]==mod) & (reg_df["Variable"]==av)
        pv   = reg_df.loc[mask, "P_value"].values
        if len(pv) > 0:
            reg_df.loc[mask, "P_BH"] = bh_fdr(pv)
    reg_df["Sig_BH"] = reg_df.get("P_BH",
        pd.Series(np.nan, index=reg_df.index)).apply(
        lambda p: sig_stars(p) if not (isinstance(p, float) and np.isnan(p)) else "")

    # Summary
    for mod in ["M1","M1r","M2","M2r"]:
        av = "ASVI_win(t-1)" if mod.endswith("r") else "ASVI(t-1)"
        sm = reg_df[(reg_df["Model"]==mod) & (reg_df["Variable"]==av)]
        if sm.empty: continue
        n5   = (sm["P_value"] < 0.05).sum()
        mb   = sm["Coef"].mean()
        n5bh = (sm["P_BH"] < 0.05).sum() if "P_BH" in sm.columns else "—"
        log(f"\n  {mod} ASVI: {n5}/15 sig @5% (BH:{n5bh}) mean β={mb:.5f}", "OK")

    return reg_df, boot_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 14: SUBPERIOD + CHOW TEST
# ═══════════════════════════════════════════════════════════════════════

def run_subperiod_regressions(df):
    section("SUBPERIOD ANALYSIS + CHOW TEST")
    sp_rows   = []
    chow_rows = []
    df_pre    = df[df["Week"] < BREAK_2022_START].copy()
    df_post   = df[df["Week"] > BREAK_2022_END  ].copy()
    LAB_MAP   = {"ASVI_L1":"ASVI(t-1)",
                 "Weekly_Volatility_L1":"Vol(t-1)",
                 "LnVol_L1":"LnVol(t-1)"}
    for t in sorted(df["Ticker"].unique()):
        sub_pre  = df_pre[df_pre["Ticker"]==t]
        sub_post = df_post[df_post["Ticker"]==t]
        for period, sub_p in [("pre_2022", sub_pre), ("post_2022", sub_post)]:
            x_pref = ["ASVI_L1","Weekly_Volatility_L1","LnVol_L1"]
            r, x_used, _ = _smart_reg(sub_p, "Weekly_Volatility", x_pref, t)
            if r is None: continue
            sec = df[df["Ticker"]==t]["Sector"].iloc[0]
            for i, lab in enumerate(["Intercept"]+[LAB_MAP.get(x,x) for x in x_used]):
                sp_rows.append({
                    "Ticker": t, "Sector": sec, "Period": period,
                    "Variable": lab,
                    "Coef": round(float(r["coef"][i]),6),
                    "SE_HAC": round(float(r["se"][i]),6),
                    "P_value": round(float(r["p"][i]),4),
                    "Sig": sig_stars(r["p"][i]),
                    "Adj_R2": round(r["adj_r2"],4), "N": r["n"],
                })
            log(f"  {t} {period}: β(ASVI)={r['coef'][1]:+.5f} "
                f"p={r['p'][1]:.3f}{sig_stars(r['p'][1]):<3} N={r['n']}")

        # Chow test
        F_c, p_c = chow_test(sub_pre.copy(), sub_post.copy(),
                              "Weekly_Volatility",
                              ["ASVI_L1","Weekly_Volatility_L1"])
        sec  = df[df["Ticker"]==t]["Sector"].iloc[0]
        interp = ("Structural break detected" if not np.isnan(p_c) and p_c < 0.05
                  else "Stable coefficients across 2022 break")
        chow_rows.append({
            "Ticker": t, "Sector": sec,
            "Y_col": "Weekly_Volatility",
            "F_Chow": F_c, "P_Chow": p_c,
            "Sig": sig_stars(p_c),
            "Interpretation": interp,
        })
        if not np.isnan(p_c) and p_c < 0.05:
            log(f"  {t} Chow F={F_c:.3f} p={p_c:.3f} {sig_stars(p_c)} BREAK", "WARN")

        # YNDX extra 2024 split
        if t == "YNDX":
            sp_pre24  = df_post[(df_post["Ticker"]=="YNDX") &
                                (df_post["Week"] < BREAK_YNDX_2024)]
            sp_post24 = df_post[(df_post["Ticker"]=="YNDX") &
                                (df_post["Week"] >= BREAK_YNDX_2024)]
            for period, sub_p in [("post22_preYNDX24", sp_pre24),
                                   ("post_YNDX24", sp_post24)]:
                r, x_used, _ = _smart_reg(sub_p, "Weekly_Volatility",
                                          ["ASVI_L1","Weekly_Volatility_L1"], "YNDX")
                if r is None: continue
                for i, lab in enumerate(["Intercept"]+[LAB_MAP.get(x,x) for x in x_used]):
                    sp_rows.append({
                        "Ticker": "YNDX", "Sector": "ConsumerTech",
                        "Period": period, "Variable": lab,
                        "Coef": round(float(r["coef"][i]),6),
                        "SE_HAC": round(float(r["se"][i]),6),
                        "P_value": round(float(r["p"][i]),4),
                        "Sig": sig_stars(r["p"][i]),
                        "Adj_R2": round(r["adj_r2"],4), "N": r["n"],
                    })

    sp_df   = pd.DataFrame(sp_rows)
    chow_df = pd.DataFrame(chow_rows)
    n_break = (chow_df["P_Chow"] < 0.05).sum()
    log(f"\n  Chow: {n_break}/{len(chow_df)} firms structural break @5%", "OK")
    return sp_df, chow_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 15: PANEL FE + DRISCOLL-KRAAY  (NEW 6)
# ═══════════════════════════════════════════════════════════════════════

def run_panel_regressions(df):
    section("PANEL FE: NW-HAC AND DRISCOLL-KRAAY SE  [NEW 6]")
    rows   = []
    specs  = [
        ("FE_M1",    "Weekly_Volatility",
         ["ASVI_L1","Weekly_Volatility_L1","crisis"],
         "Panel FE — Volatility (max N)"),
        ("FE_M1_LV", "Weekly_Volatility",
         ["ASVI_L1","Weekly_Volatility_L1","LnVol_L1","crisis"],
         "Panel FE — Volatility (with LnVol)"),
        ("FE_M2",    "Weekly_Return",
         ["ASVI_L1","Weekly_Return_L1","Weekly_Volatility_L1","crisis"],
         "Panel FE — Return"),
        ("FE_M1w",   "Weekly_Volatility",
         ["ASVI_w_L1","Weekly_Volatility_L1","crisis"],
         "Panel FE — Volatility (winsorised ASVI)"),
    ]
    for (mod, y_col, x_cols, label) in specs:
        r_hac = panel_ols_fe(df, y_col, x_cols)
        df_dk = df[["Ticker","Week",y_col]+x_cols].copy()
        r_dk  = driscoll_kraay_se(df_dk, y_col, x_cols)
        if r_hac is None and r_dk is None:
            log(f"  {label}: insufficient data", "WARN")
            continue
        r   = r_hac if r_hac else r_dk
        N   = r["n"]
        r2  = r["r2"]
        log(f"\n  {label}  N={N}  R²={r2:.4f}  [NW-HAC | DK]")
        for i, lab in enumerate(x_cols):
            se_hac = float(r_hac["se"][i]) if r_hac and len(r_hac["se"]) > i else np.nan
            p_hac  = float(r_hac["p"][i])  if r_hac and len(r_hac["p"])  > i else np.nan
            se_dk  = float(r_dk["se_dk"][i]) if r_dk and len(r_dk["se_dk"]) > i else np.nan
            p_dk   = float(r_dk["p_dk"][i])  if r_dk and len(r_dk["p_dk"])  > i else np.nan
            b      = float(r["coef"][i])
            log(f"    {lab:<32} β={b:>+9.5f} "
                f"p_NW={p_hac:.3f}{sig_stars(p_hac):<3} "
                f"p_DK={p_dk:.3f}{sig_stars(p_dk):<3}")
            rows.append({
                "Model": mod, "Label": label, "Variable": lab,
                "Coef": round(b, 6),
                "SE_NW": round(se_hac, 6) if not np.isnan(se_hac) else np.nan,
                "P_NW":  round(p_hac, 4)  if not np.isnan(p_hac)  else np.nan,
                "Sig_NW": sig_stars(p_hac),
                "SE_DK": round(se_dk, 6) if not np.isnan(se_dk) else np.nan,
                "P_DK":  round(p_dk, 4)  if not np.isnan(p_dk)  else np.nan,
                "Sig_DK": sig_stars(p_dk),
                "R2_within": round(r2, 4), "N": N,
            })
    return pd.DataFrame(rows)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 16: CORRELATION MATRIX
# ═══════════════════════════════════════════════════════════════════════

def correlation_analysis(df):
    section("CORRELATION ANALYSIS")
    rows = []
    for t in sorted(df["Ticker"].unique()):
        sub = df[df["Ticker"]==t]
        for (x, y) in [
            ("ASVI", "Weekly_Volatility"),
            ("ASVI_L1", "Weekly_Volatility"),
            ("ASVI", "Weekly_Return"),
            ("ASVI_L1", "Weekly_Return"),
        ]:
            if x not in sub.columns or y not in sub.columns: continue
            d = sub[[x, y]].dropna()
            if len(d) < 20: continue
            r_p, p_p = st.pearsonr(d[x], d[y])
            r_s, p_s = st.spearmanr(d[x], d[y])
            rows.append({
                "Ticker": t, "Sector": sub["Sector"].iloc[0],
                "X": x, "Y": y, "N": len(d),
                "Pearson_r": round(float(r_p), 4),
                "Pearson_p": round(float(p_p), 4),
                "Spearman_r": round(float(r_s), 4),
                "Spearman_p": round(float(p_s), 4),
            })
    corr_df = pd.DataFrame(rows)
    key = corr_df[(corr_df["X"]=="ASVI_L1") & (corr_df["Y"]=="Weekly_Volatility")]
    if not key.empty:
        n_pos = (key["Pearson_r"] > 0).sum()
        n_sig = (key["Pearson_p"] < 0.05).sum()
        log(f"  ASVI(t-1)→Vol(t): {n_pos}/15 positive, {n_sig}/15 sig @5% (Pearson)", "OK")
    return corr_df


# ═══════════════════════════════════════════════════════════════════════
# SECTION 17: CHARTS
# ═══════════════════════════════════════════════════════════════════════

def _safe_plot(fn, name):
    try:
        fn()
        log(f"  Saved: {name}", "OK")
    except Exception as e:
        log(f"  {name}: {e}", "WARN")


def plot_company(df, ticker, reg_df):
    sub = df[df["Ticker"]==ticker].sort_values("Week").copy()
    if len(sub) < 20: return
    col = SECTOR_COLORS.get(sub["Sector"].iloc[0], "steelblue")
    fig = plt.figure(figsize=(16, 11))
    cname = sub["Company"].iloc[0] if "Company" in sub.columns else ticker
    fig.suptitle(f"{ticker} — {cname}  ({sub['Sector'].iloc[0]})",
                 fontsize=13, fontweight="bold", y=0.995)
    gs   = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.38,
                             left=0.07, right=0.97, top=0.93, bottom=0.06)
    ax1  = fig.add_subplot(gs[0, :2])
    ax2  = fig.add_subplot(gs[0, 2])
    ax3  = fig.add_subplot(gs[1, 0])
    ax4  = fig.add_subplot(gs[1, 1])
    ax5  = fig.add_subplot(gs[1, 2])
    weeks = sub["Week"]

    # A: Price + SVI
    ax1b = ax1.twinx()
    ax1.plot(weeks, sub["Close"], color=col, lw=1.4, zorder=3, label="Close (RUB)")
    if "SVI_MAX" in sub.columns:
        ax1b.fill_between(weeks, sub["SVI_MAX"].fillna(0)/1e6,
                          alpha=0.18, color="darkorange")
        ax1b.plot(weeks, sub["SVI_MAX"].fillna(0)/1e6,
                  color="darkorange", lw=0.9, alpha=0.8)
    ax1.axvspan(BREAK_2022_START, BREAK_2022_END, alpha=0.13, color="red")
    if ticker == "YNDX":
        ax1.axvline(BREAK_YNDX_2024, color="purple", lw=1.2, ls="--")
    if ticker == "GAZP":
        ax1.axvspan(GAZP_EVENT_START, GAZP_EVENT_END, alpha=0.15, color="orange")
    ax1.set_title("A  Close Price & SVI", loc="left", fontweight="bold")
    ax1.set_ylabel("Price (RUB)", color=col)
    ax1b.set_ylabel("SVI ×10⁶", color="darkorange")
    ax1.tick_params(axis="x", rotation=25)

    # B: ASVI
    asvi = sub["ASVI"].fillna(0)
    ax2.fill_between(weeks, asvi, 0, where=(asvi>0), color=col, alpha=0.55)
    ax2.fill_between(weeks, asvi, 0, where=(asvi<0), color="grey", alpha=0.4)
    if sub["ASVI"].notna().sum() > 5:
        mu_, sd_ = sub["ASVI"].mean(), sub["ASVI"].std()
        ax2.axhline(mu_+sd_, color="red",  lw=0.8, ls="--")
        ax2.axhline(mu_-sd_, color="navy", lw=0.8, ls="--")
        ax2.axhline(0, color="black", lw=0.6)
    ax2.axvspan(BREAK_2022_START, BREAK_2022_END, alpha=0.13, color="red")
    ax2.set_title("B  ASVI", loc="left", fontweight="bold")
    ax2.tick_params(axis="x", rotation=25)

    # C: Return distribution
    ret = sub["Weekly_Return"].dropna()
    if len(ret) > 10:
        ax3.hist(ret, bins=40, density=True, color=col, alpha=0.5,
                 edgecolor="white", lw=0.3, label="Raw")
        xs_ = np.linspace(ret.quantile(0.005), ret.quantile(0.995), 200)
        try:
            ax3.plot(xs_, st.gaussian_kde(ret)(xs_), color=col, lw=2)
        except Exception:
            pass
        ax3.plot(xs_, st.norm.pdf(xs_, ret.mean(), ret.std()),
                 "k--", lw=1.2, alpha=0.7)
        jb_s, jb_p = jarque_bera(ret)
        ax3.text(0.97, 0.95,
                 f"Skew={st.skew(ret):.3f}\nKurt={st.kurtosis(ret):.3f}\nJB p={jb_p:.3f}",
                 transform=ax3.transAxes, ha="right", va="top", fontsize=8,
                 bbox=dict(boxstyle="round,pad=0.3", fc="white", alpha=0.85))
    ax3.set_title("C  Return Distribution", loc="left", fontweight="bold")
    ax3.set_xlabel("Weekly Return")
    ax3.set_ylabel("Density")

    # D: ASVI(t-1) vs Vol scatter
    scat = sub[["ASVI_L1","Weekly_Volatility"]].dropna()
    ax4.scatter(scat["ASVI_L1"], scat["Weekly_Volatility"],
                alpha=0.28, s=13, color=col, edgecolors="none")
    if len(scat) > 15:
        xs_ = np.column_stack([np.ones(len(scat)), scat["ASVI_L1"].values])
        r_  = ols_hac(scat["Weekly_Volatility"].values, xs_)
        if r_:
            xr = np.linspace(scat["ASVI_L1"].quantile(0.05),
                             scat["ASVI_L1"].quantile(0.95), 80)
            ax4.plot(xr, r_["coef"][0]+r_["coef"][1]*xr, "r-", lw=2)
            ax4.text(0.04, 0.95,
                     f"β={r_['coef'][1]:.4f}\np={r_['p'][1]:.3f}{sig_stars(r_['p'][1])}",
                     transform=ax4.transAxes, fontsize=9,
                     bbox=dict(boxstyle="round,pad=0.3", fc="white", alpha=0.85))
    ax4.set_title("D  ASVI(t−1) → Vol(t)", loc="left", fontweight="bold")
    ax4.set_xlabel("ASVI (lag 1)")
    ax4.set_ylabel("Realized Volatility")

    # E: Pre/Post 2022 ASVI violin
    pre_a  = sub[sub["Week"] < BREAK_2022_START]["ASVI"].dropna()
    post_a = sub[sub["Week"] > BREAK_2022_END ]["ASVI"].dropna()
    if len(pre_a) > 5 and len(post_a) > 5:
        vp = ax5.violinplot([pre_a, post_a], positions=[0, 1], showmedians=True)
        for body in vp["bodies"]:
            body.set_alpha(0.55)
        vp["bodies"][0].set_facecolor("#2166ac")
        vp["bodies"][1].set_facecolor("#d6604d")
        ax5.set_xticks([0, 1])
        ax5.set_xticklabels(["Pre-2022","Post-2022"])
        _, tp = st.ttest_ind(pre_a, post_a)
        ax5.set_title(f"E  ASVI Pre/Post 2022  p={tp:.3f}{sig_stars(tp)}",
                      loc="left", fontweight="bold", fontsize=9)
        ax5.axhline(0, color="black", lw=0.7, ls="--")

    fig.savefig(os.path.join(GDIR, f"{ticker}_analysis.png"),
                dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def plot_summary_panels(df, reg_df, gc_df, boot_df, har_df,
                         garch_df, qr_df, ev_df, pwr_df, false_df):
    """Generate all v4 summary charts."""
    os.makedirs(GDIR, exist_ok=True)

    # 1: Coefficient forest M1/M2
    def _coef_forest():
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 7))
        fig.suptitle("M1/M2: ASVI(t-1) Coefficients ± 95% CI",
                     fontweight="bold", fontsize=11)
        for ax, mod, title in [(ax1,"M1","M1: ASVI→Vol"),
                                (ax2,"M2","M2: ASVI→Ret")]:
            sm = reg_df[(reg_df["Model"]==mod) &
                        (reg_df["Variable"]=="ASVI(t-1)")].copy()
            if sm.empty: continue
            order = [t for t in COMPANY_ORDER if t in sm["Ticker"].values]
            sm = sm.set_index("Ticker").loc[order].reset_index()
            y_pos = np.arange(len(sm))
            cols_ = [SECTOR_COLORS.get(s,"grey") for s in sm["Sector"]]
            # HAC CI
            hac_lo = sm["Coef"] - 1.96*sm["SE_HAC"]
            hac_hi = sm["Coef"] + 1.96*sm["SE_HAC"]
            ax.hlines(y_pos, hac_lo, hac_hi, colors=cols_, lw=2.5, alpha=0.6)
            ax.scatter(sm["Coef"], y_pos, c=cols_, s=60, zorder=4)
            # Bootstrap CI overlay
            if not boot_df.empty:
                boot_m = boot_df[boot_df["Model"]==mod].set_index("Ticker")
                for j, t in enumerate(sm["Ticker"]):
                    if t in boot_m.index:
                        ax.hlines(j, boot_m.loc[t,"Boot_CI_lo"],
                                  boot_m.loc[t,"Boot_CI_hi"],
                                  colors="black", lw=1.2, ls="--", alpha=0.8)
            ax.axvline(0, color="black", lw=0.8)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sm["Ticker"], fontsize=8)
            ax.set_title(title, fontweight="bold")
            ax.set_xlabel("β ± 95% CI (solid=HAC, dashed=Bootstrap)")
            # Stars
            for j, (_, row) in enumerate(sm.iterrows()):
                if row.get("Sig",""):
                    ax.text(hac_hi.iloc[j]+0.001, j, row["Sig"],
                            va="center", fontsize=9, color="red")
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_01_coef_forest_bootstrap.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 2: BH-FDR visualization
    def _bh_fdr():
        sub = reg_df[(reg_df["Model"]=="M1") &
                     (reg_df["Variable"]=="ASVI(t-1)")].copy()
        if sub.empty or "P_BH" not in sub.columns: return
        sub = sub.sort_values("P_value")
        m   = len(sub)
        fig, ax = plt.subplots(figsize=(9, 5))
        y_pos = np.arange(m)
        ax.scatter(sub["P_value"].values, y_pos, color="#2166ac",
                   s=60, zorder=3, label="Raw p-value")
        if sub["P_BH"].notna().any():
            ax.scatter(sub["P_BH"].values, y_pos, color="#d6604d",
                       marker="D", s=60, zorder=3, label="BH-adjusted p")
        bh_thresh = np.array([(i+1)/m*ALPHA for i in range(m)])
        ax.plot(bh_thresh, y_pos, "k--", lw=1.2, label=f"BH threshold (α={ALPHA})")
        ax.axvline(0.05, color="grey", lw=0.8, ls=":")
        ax.set_yticks(y_pos)
        ax.set_yticklabels(sub["Ticker"].values, fontsize=8)
        ax.set_xlabel("p-value")
        ax.set_title("BH-FDR Correction: M1 ASVI(t-1)", fontweight="bold")
        ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_02_bh_fdr.png"), dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 3: HAR-RV comparison
    def _har_comp():
        if har_df is None or har_df.empty: return
        base = har_df[har_df["Model"]=="HAR_RV"].groupby("Ticker")["R2"].max()
        ext  = har_df[har_df["Model"]=="HAR_RV_ASVI"].groupby("Ticker")["R2"].max()
        common = sorted(set(base.index) & set(ext.index))
        if not common: return
        fig, ax = plt.subplots(figsize=(8, 6))
        x_vals = base.reindex(common).values
        y_vals = ext.reindex(common).values
        cols_  = [SECTOR_COLORS.get(
            har_df[har_df["Ticker"]==t]["Sector"].iloc[0],"grey")
            for t in common]
        ax.scatter(x_vals, y_vals, c=cols_, s=80, zorder=3, edgecolors="white")
        lim = [min(x_vals.min(), y_vals.min())-0.01,
               max(x_vals.max(), y_vals.max())+0.01]
        ax.plot(lim, lim, "k--", lw=1, alpha=0.5, label="y=x (no gain)")
        for i, t in enumerate(common):
            ax.annotate(t, (x_vals[i], y_vals[i]), fontsize=8,
                        xytext=(4,4), textcoords="offset points")
        ax.set_title("HAR-RV vs HAR-RV-ASVI R²\n(above diagonal = ASVI improves fit)",
                     fontweight="bold")
        ax.set_xlabel("HAR-RV R²")
        ax.set_ylabel("HAR-RV-ASVI R²")
        ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_03_har_comparison.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 4: GARCH persistence
    def _garch_bars():
        if garch_df is None or garch_df.empty: return
        g11   = garch_df[(garch_df["Model"]=="GARCH11")].groupby(
            "Ticker")["Persistence"].first()
        gasvi = garch_df[(garch_df["Model"]=="GARCH_ASVI") &
                         (garch_df["Param"]=="delta_asvi")][
            ["Ticker","Estimate","P_value","Sig"]].copy()
        tks = sorted(g11.index)
        if not tks: return
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
        fig.suptitle("GARCH(1,1) Results", fontsize=11, fontweight="bold")
        cols_ = [SECTOR_COLORS.get(
            garch_df[garch_df["Ticker"]==t]["Sector"].iloc[0],"grey")
            for t in tks]
        ax1.barh(tks, [g11.get(t, np.nan) for t in tks],
                 color=cols_, edgecolor="white")
        ax1.axvline(0.95, color="red", lw=1.5, ls="--", label="persist=0.95")
        ax1.set_title("GARCH(1,1) Persistence (α+β)")
        ax1.set_xlabel("α+β")
        ax1.legend(fontsize=8)
        gasvi_idx = gasvi.set_index("Ticker")
        tks2 = [t for t in tks if t in gasvi_idx.index]
        if tks2:
            cols2 = [SECTOR_COLORS.get(
                garch_df[garch_df["Ticker"]==t]["Sector"].iloc[0],"grey")
                for t in tks2]
            bars = ax2.barh(tks2, [float(gasvi_idx.loc[t,"Estimate"]) for t in tks2],
                            color=cols2, edgecolor="white")
            ax2.axvline(0, color="black", lw=0.8)
            for bar, t in zip(bars, tks2):
                s = gasvi_idx.loc[t,"Sig"] if t in gasvi_idx.index else ""
                if s:
                    ax2.text(bar.get_width()+1e-6,
                             bar.get_y()+bar.get_height()/2,
                             s, va="center", fontsize=9, color="red")
            ax2.set_title("GARCH-ASVI: δ(ASVI) in variance equation")
            ax2.set_xlabel("δ estimate")
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_04_garch_persistence.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 5: Quantile ASVI coefficients
    def _quantile_plot():
        if qr_df is None or qr_df.empty: return
        sub = qr_df[qr_df["Variable"]=="ASVI(t-1)"]
        tks = sorted(sub["Ticker"].unique())
        pal = sns.color_palette("tab15", len(tks))
        fig, ax = plt.subplots(figsize=(10, 5))
        for i, t in enumerate(tks):
            s_t = sub[sub["Ticker"]==t].sort_values("Tau")
            ax.plot(s_t["Tau"], s_t["Coef"], marker="o", lw=1.4,
                    color=pal[i], label=t, markersize=5, alpha=0.8)
        ax.axhline(0, color="black", lw=0.8, ls="--")
        ax.set_title("Quantile Regression: ASVI(t-1) → Vol(t) across τ",
                     fontweight="bold")
        ax.set_xlabel("Quantile τ")
        ax.set_ylabel("β(ASVI)")
        ax.legend(fontsize=7, ncol=3, bbox_to_anchor=(1.01, 1), loc="upper left")
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_05_quantile_asvi.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 6: Event study
    def _event_plot():
        if ev_df is None or ev_df.empty: return
        agg    = ev_df.groupby("Relative_t")[
            ["Abnormal_Return","Abnormal_Volatility"]].agg(["mean","sem"])
        rel_ts = sorted(agg.index)
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        fig.suptitle("Event Study: ASVI Spike Windows (±4 weeks)",
                     fontsize=11, fontweight="bold")
        for ax, col, title, ylab in [
            (ax1,"Abnormal_Return","CAAR","CAR"),
            (ax2,"Abnormal_Volatility","CAAV","CAV"),
        ]:
            means = agg[(col,"mean")].reindex(rel_ts).values
            sems  = agg[(col,"sem")].reindex(rel_ts).values
            ax.fill_between(rel_ts, means-1.96*sems, means+1.96*sems,
                            alpha=0.2, color="steelblue")
            ax.plot(rel_ts, means, "o-", lw=2, color="steelblue")
            ax.axvline(0, color="red", lw=1.5, ls="--", label="Event t=0")
            ax.axhline(0, color="black", lw=0.8)
            ax.set_title(title, fontweight="bold")
            ax.set_xlabel("Weeks relative to ASVI spike")
            ax.set_ylabel(ylab)
            ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_06_event_study.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 7: Power MDE
    def _power_plot():
        if pwr_df is None or pwr_df.empty: return
        order = pwr_df.sort_values("Actual_Power")["Ticker"].values
        cols_ = ["#d6604d" if v < 0.80 else "#2166ac"
                 for v in pwr_df.set_index("Ticker").loc[order,"Actual_Power"]]
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        fig.suptitle("Statistical Power Analysis (M1: ASVI→Volatility)",
                     fontsize=11, fontweight="bold")
        ax1.barh(order, pwr_df.set_index("Ticker").loc[order,"Actual_Power"],
                 color=cols_, edgecolor="white")
        ax1.axvline(0.80, color="red", lw=1.5, ls="--", label="80% power threshold")
        ax1.set_title("Actual Power for Observed β(ASVI)")
        ax1.set_xlabel("Power")
        ax1.legend(fontsize=8)
        ax2.barh(order, pwr_df.set_index("Ticker").loc[order,"MDE_80pct"].abs()*10000,
                 color="#4dac26", alpha=0.8, edgecolor="white")
        ax2.set_title("MDE at 80% Power (×10⁴)")
        ax2.set_xlabel("|MDE| × 10,000")
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_07_power_mde.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 8: Falsification
    def _false_plot():
        if false_df is None or false_df.empty: return
        order = false_df.sort_values("P_false_twosided")["Ticker"].values
        cols_ = ["#d6604d" if c=="GENUINE" else "#aaaaaa"
                 for c in false_df.set_index("Ticker").loc[order,"Conclusion"]]
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.barh(order, false_df.set_index("Ticker").loc[order,"Beta_observed"]*10000,
                color=cols_, edgecolor="white", height=0.5)
        ax.axvline(0, color="black", lw=0.8)
        ax2 = ax.twiny()
        ax2.plot(false_df.set_index("Ticker").loc[order,"P_false_twosided"],
                 np.arange(len(order)), "k^", markersize=7, label="p_false")
        ax2.axvline(0.10, color="red", lw=1.5, ls="--", label="p=0.10")
        ax.set_xlabel("β(ASVI) × 10,000")
        ax2.set_xlabel("p_false (top axis)")
        ax.set_title("Falsification Test: Observed β vs Shuffled ASVI\n"
                     "Red=genuine (p_false≤0.10)", fontweight="bold")
        ax2.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"NEW_08_falsification.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 9: Scatter grid
    def _scatter_grid():
        tks  = [t for t in COMPANY_ORDER if t in df["Ticker"].unique()]
        fig, axes = plt.subplots(5, 3, figsize=(13, 16))
        fig.suptitle("ASVI(t-1) → Realized Volatility(t) per Company",
                     fontsize=11, fontweight="bold")
        for i, ax in enumerate(axes.flat):
            if i >= len(tks):
                ax.set_visible(False)
                continue
            t   = tks[i]
            sub = df[df["Ticker"]==t].sort_values("Week")
            sc  = sub[["ASVI_L1","Weekly_Volatility"]].dropna()
            col = SECTOR_COLORS.get(sub["Sector"].iloc[0], "steelblue")
            ax.scatter(sc["ASVI_L1"], sc["Weekly_Volatility"],
                       alpha=0.28, s=11, color=col)
            if len(sc) > 10:
                xs_ = np.column_stack([np.ones(len(sc)), sc["ASVI_L1"].values])
                r_  = ols_hac(sc["Weekly_Volatility"].values, xs_)
                if r_:
                    xr = np.linspace(sc["ASVI_L1"].quantile(0.05),
                                     sc["ASVI_L1"].quantile(0.95), 60)
                    ax.plot(xr, r_["coef"][0]+r_["coef"][1]*xr, "r-", lw=1.5)
                    ax.set_title(f"{t}  β={r_['coef'][1]:.3f}{sig_stars(r_['p'][1])}",
                                 fontsize=9, fontweight="bold")
            ax.set_xlabel("ASVI(t−1)", fontsize=7.5)
            ax.set_ylabel("Vol(t)", fontsize=7.5)
            ax.tick_params(labelsize=7)
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"PANEL_scatter_grid.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    # 10: Granger heatmap
    def _granger_heatmap():
        if gc_df is None or gc_df.empty: return
        tks  = COMPANY_ORDER
        lags = [1, 2, 4]
        fig, axes = plt.subplots(1, 2, figsize=(13, 6))
        fig.suptitle("Granger Causality p-values (parametric)",
                     fontsize=11, fontweight="bold")
        for ax, h, title in [
            (axes[0],"H1: ASVI→Vol","H1: ASVI→Volatility"),
            (axes[1],"H2: ASVI→Ret","H2: ASVI→Return"),
        ]:
            mat = pd.DataFrame(index=tks, columns=lags, dtype=float)
            for t in tks:
                for lag in lags:
                    row = gc_df[(gc_df["Ticker"]==t) &
                                (gc_df["Hypothesis"]==h) &
                                (gc_df["Lag"]==lag)]
                    if not row.empty:
                        mat.loc[t, lag] = float(row["P_param"].values[0])
            mat = mat.astype(float)
            im = ax.imshow(mat.values, aspect="auto", cmap="RdYlGn_r",
                           vmin=0, vmax=0.20)
            ax.set_xticks(range(len(lags)))
            ax.set_xticklabels([f"lag={l}" for l in lags])
            ax.set_yticks(range(len(tks)))
            ax.set_yticklabels(tks, fontsize=8)
            ax.set_title(title, fontweight="bold")
            plt.colorbar(im, ax=ax, label="p-value")
            # Significance annotations
            for i, t in enumerate(tks):
                for j, lag in enumerate(lags):
                    v = mat.loc[t, lag]
                    if not np.isnan(v):
                        ax.text(j, i, sig_stars(v), ha="center", va="center",
                                fontsize=9, color="white" if v < 0.05 else "black")
        fig.tight_layout()
        fig.savefig(os.path.join(GDIR,"PANEL_granger_heatmap.png"),
                    dpi=DPI, bbox_inches="tight")
        plt.close(fig)

    section("GENERATING CHARTS")
    _safe_plot(_coef_forest,      "NEW_01_coef_forest_bootstrap.png")
    _safe_plot(_bh_fdr,           "NEW_02_bh_fdr.png")
    _safe_plot(_har_comp,         "NEW_03_har_comparison.png")
    _safe_plot(_garch_bars,       "NEW_04_garch_persistence.png")
    _safe_plot(_quantile_plot,    "NEW_05_quantile_asvi.png")
    _safe_plot(_event_plot,       "NEW_06_event_study.png")
    _safe_plot(_power_plot,       "NEW_07_power_mde.png")
    _safe_plot(_false_plot,       "NEW_08_falsification.png")
    _safe_plot(_scatter_grid,     "PANEL_scatter_grid.png")
    _safe_plot(_granger_heatmap,  "PANEL_granger_heatmap.png")

    # Per-company charts
    for t in COMPANY_ORDER:
        if t in df["Ticker"].unique():
            _safe_plot(lambda t=t: plot_company(df, t, reg_df),
                       f"{t}_analysis.png")


# ═══════════════════════════════════════════════════════════════════════
# SECTION 18: WRITE REPORTS
# ═══════════════════════════════════════════════════════════════════════

def write_analysis_report(df, desc_df, gc_df, reg_df, boot_df,
                           panel_df, sp_df, chow_df, har_df, garch_df,
                           qr_df, pwr_df, false_df, ev_df, pt_df, path):
    """Write comprehensive ANALYSIS_REPORT_v4.txt."""

    def _a(mod, v):
        sm = reg_df[(reg_df["Model"]==mod) & (reg_df["Variable"]==v)]
        if sm.empty: return "N/A"
        n5   = (sm["P_value"] < 0.05).sum()
        mb   = sm["Coef"].mean()
        n5bh = (sm["P_BH"] < 0.05).sum() if "P_BH" in sm.columns else "—"
        sigs = list(sm[sm["P_value"] < 0.05]["Ticker"])
        return f"{n5}/15 @5% (BH:{n5bh}) mean β={mb:.5f} {sigs}"

    def _g(h):
        sub = gc_df[(gc_df["Hypothesis"]==h) & (gc_df["Lag"]==1)]
        if sub.empty: return "N/A"
        n5   = (sub["P_param"] < 0.05).sum()
        sigs = list(sub[sub["P_param"] < 0.05]["Ticker"])
        nperm = (sub["P_perm"] < 0.05).sum() if "P_perm" in sub.columns else "—"
        return f"{n5}/15 @5% (perm:{nperm}) {sigs}"

    def _fb(b, p):
        if np.isnan(b): return "     N/A "
        return f"{b:>+.5f}{sig_stars(p):<3}"

    lines = [
        "╔"+"═"*70+"╗",
        "║  THESIS ANALYSIS REPORT  v4                                        ║",
        "║  Investor Attention and Stock Market Volatility:                   ║",
        "║  Evidence from Digital Search Data — Russian MOEX                 ║",
        "╚"+"═"*70+"╝",
        f"  Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"  Seed      : {SEED}",
        f"  Data      : {len(df):,} obs | {df['Ticker'].nunique()} companies"
        f" | {df['Week'].min().date()} – {df['Week'].max().date()}",
        "",
        "  v4 IMPROVEMENTS APPLIED:",
        "  FIX 1  GAZP Aug-Sep 2022 dividend event dummy (gazp_aug22)",
        "  FIX 2  Granger F NaN-propagation (no clamp to 0)",
        "  NEW 3  Benjamini-Hochberg FDR correction",
        "  NEW 4  HAR-RV + HAR-RV-ASVI models (Corsi 2009)",
        "  NEW 5  GARCH(1,1) + GARCH-ASVI in variance (MLE)",
        "  NEW 6  Driscoll-Kraay SE (cross-sectional dependence robust)",
        "  NEW 7  Permutation Granger (1000 shuffles per firm)",
        "  NEW 8  Moving-block bootstrap CI (B=1000, block=T^1/3)",
        "  NEW 9  Quantile regression τ=0.25/0.50/0.75/0.90 (LP)",
        "  NEW 10 Event study: ASVI spikes ±4 weeks",
        "  NEW 11 Pre-trend rolling correlation (Mann-Kendall)",
        "  NEW 12 Power/MDE analysis (non-central t)",
        "  NEW 13 Falsification test (date-shuffled ASVI, 200 iter)",
        "  NEW 14 AFLT ΔVol model (M1d for non-stationary vol)",
        "  NEW 15 Deterministic seed, JSON manifest, timing log",
    ]

    # ── SAMPLE TABLE
    lines += ["", "═"*72, "1. DATA AND SAMPLE", "═"*72, ""]
    lines.append(f"  {'Ticker':<6}  {'Company':<24}  {'Sector':<14}  {'N':>5}")
    lines.append("  " + "─"*54)
    for t in COMPANY_ORDER:
        st_ = df[df["Ticker"]==t]
        if len(st_)==0: continue
        cname = st_["Company"].iloc[0] if "Company" in st_.columns else t
        lines.append(f"  {t:<6}  {cname:<24}  {st_['Sector'].iloc[0]:<14}  {len(st_):>5}")
    lines += [
        "",
        "  SAMPLE NOTES:",
        "  • TCSG N≈322: IPO Nov 2019 — ~25% lower power than others",
        "  • YNDX: Jul 2024 Dutch→Russian restructure — yndx_break dummy",
        "  • MOEX: market index — LnVol excluded (only 15.8% non-null)",
        "  • ALL: 2022 MOEX closure (crisis dummy ±4 wks)",
        "  • GAZP: Aug-Sep 2022 +37.7% extreme return → gazp_aug22 dummy [FIX 1]",
        "  • Returns winsorised ±3.5σ | ASVI winsorised ±4σ (robustness only)",
    ]

    # ── DESCRIPTIVE STATS
    lines += ["", "═"*72, "2. DESCRIPTIVE STATISTICS", "═"*72, ""]
    for var_label, var_col in [
        ("Weekly Return", "Weekly Return"),
        ("Realized Volatility", "Realized Volatility"),
        ("ASVI", "ASVI"),
    ]:
        sub_d = desc_df[desc_df["Variable"]==var_col]
        lines.append(f"  {var_label}:")
        lines.append(f"  {'Ticker':<6} {'N':>4}  {'Mean':>9} {'Std':>8} "
                     f"{'Skew':>7} {'Kurt':>8}  I(0)")
        lines.append("  " + "─"*56)
        for _, r in sub_d.iterrows():
            lines.append(f"  {r['Ticker']:<6} {r['N']:>4}  "
                         f"{r['Mean']:>+9.5f} {r['Std']:>8.5f} "
                         f"{r['Skewness']:>7.3f} {r['Kurtosis_excess']:>8.3f}  "
                         f"{r['I0_5pct']}")
        lines.append("")

    # ── GRANGER
    lines += ["═"*72, "3. GRANGER CAUSALITY  [parametric + permutation + BH-FDR]", "═"*72, ""]
    lines += [
        f"  H₁ (ASVI→Vol): {_g('H1: ASVI→Vol')}",
        f"  H₁w (win ASVI→Vol): {_g('H1w: ASVI_win→Vol')}",
        f"  H₂ (ASVI→Ret): {_g('H2: ASVI→Ret')}",
        "",
        f"  {'Ticker':<6} {'Sector':<14}  {'H1 F':>8} {'p_par':>8} "
        f"{'p_perm':>8} {'p_BH':>8}  {'H2 F':>8} {'p_par':>8}",
        "  " + "─"*76,
    ]
    for t in COMPANY_ORDER:
        h1 = gc_df[(gc_df["Ticker"]==t) & (gc_df["Hypothesis"]=="H1: ASVI→Vol") &
                   (gc_df["Lag"]==1)]
        h2 = gc_df[(gc_df["Ticker"]==t) & (gc_df["Hypothesis"]=="H2: ASVI→Ret") &
                   (gc_df["Lag"]==1)]
        sec = df[df["Ticker"]==t]["Sector"].iloc[0] if len(df[df["Ticker"]==t]) else ""
        def _gv(r, col):
            if r.empty or col not in r.columns: return "     N/A"
            v = r[col].values[0]
            return f"{v:8.3f}" if not np.isnan(v) else "     N/A"
        h1F   = _gv(h1, "F_stat")
        h1pp  = _gv(h1, "P_param")
        h1pm  = _gv(h1, "P_perm")
        h1bh  = _gv(h1, "P_BH")
        h2F   = _gv(h2, "F_stat")
        h2pp  = _gv(h2, "P_param")
        h1s   = sig_stars(h1["P_param"].values[0]) if not h1.empty else ""
        lines.append(f"  {t:<6} {sec:<14}  {h1F}  {h1pp}  {h1pm}  "
                     f"{h1bh}  {h1s:>3}  {h2F}  {h2pp}")
    lines += ["", "  *** p<0.01  ** p<0.05  * p<0.10",
              "  p_perm = permutation Granger (1000 shuffles)",
              "  p_BH   = Benjamini-Hochberg FDR adjusted"]

    # ── OLS RESULTS
    lines += ["", "═"*72, "4. OLS REGRESSIONS  [HAC SE + Bootstrap CI + BH-FDR]", "═"*72, ""]
    lines += [
        "  M1: Vol(t)=α+ASVI(t-1)+Vol(t-1)+[LnVol(t-1)]+Crisis[+dummies]",
        "  M2: Ret(t)=α+ASVI(t-1)+Ret(t-1)+Vol(t-1)+Crisis",
        "",
        f"  M1  ASVI: {_a('M1', 'ASVI(t-1)')}",
        f"  M1r ASVI: {_a('M1r','ASVI_win(t-1)')}",
        f"  M2  ASVI: {_a('M2', 'ASVI(t-1)')}",
        "",
        f"  {'Ticker':<6} {'Sector':<14}  {'M1 β':>11}  {'M2 β':>11}  "
        f"{'Boot CI M1':>24}  {'R²M1':>6}  N",
        "  " + "─"*84,
    ]
    for t in COMPANY_ORDER:
        m1 = reg_df[(reg_df["Ticker"]==t) & (reg_df["Model"]=="M1") &
                    (reg_df["Variable"]=="ASVI(t-1)")]
        m2 = reg_df[(reg_df["Ticker"]==t) & (reg_df["Model"]=="M2") &
                    (reg_df["Variable"]=="ASVI(t-1)")]
        b1 = m1["Coef"].values[0]   if not m1.empty else np.nan
        p1 = m1["P_value"].values[0] if not m1.empty else np.nan
        b2 = m2["Coef"].values[0]   if not m2.empty else np.nan
        p2 = m2["P_value"].values[0] if not m2.empty else np.nan
        r2m1 = reg_df[(reg_df["Ticker"]==t) & (reg_df["Model"]=="M1")][
            "Adj_R2"].max()
        nm1  = reg_df[(reg_df["Ticker"]==t) & (reg_df["Model"]=="M1")]["N"].max()
        sec  = df[df["Ticker"]==t]["Sector"].iloc[0] if len(df[df["Ticker"]==t]) else ""
        bc_row = boot_df[(boot_df["Ticker"]==t) & (boot_df["Model"]=="M1")] \
                 if not boot_df.empty else pd.DataFrame()
        bci = (f"[{bc_row['Boot_CI_lo'].values[0]:+.4f},"
               f"{bc_row['Boot_CI_hi'].values[0]:+.4f}]"
               if not bc_row.empty else "           N/A")
        lines.append(f"  {t:<6} {sec:<14}  {_fb(b1,p1):>11}  "
                     f"{_fb(b2,p2):>11}  {bci:>24}  "
                     f"{r2m1:>6.4f}  {int(nm1) if not np.isnan(nm1) else 'NA'}")
    lines += ["", "  *** p<0.01  ** p<0.05  * p<0.10  (HAC SE)",
              "  Boot CI = 95% moving-block bootstrap"]

    # ── HAR-RV
    lines += ["", "═"*72, "5. HAR-RV MODELS  [Corsi 2009]", "═"*72, ""]
    if har_df is not None and not har_df.empty:
        ha    = har_df[har_df["Model"]=="HAR_RV_ASVI"]
        arows = ha[ha["Variable"]=="γ_ASVI"]
        r2c   = har_df.groupby(["Ticker","Model"])["R2"].max().unstack("Model")
        lines.append(f"  {'Ticker':<6} {'γ(ASVI)':>13}  {'p':>7}  "
                     f"{'HAR R²':>7}  {'HAR-ASVI R²':>12}  ΔR²")
        lines.append("  " + "─"*60)
        for t in COMPANY_ORDER:
            row = arows[arows["Ticker"]==t]
            if row.empty: continue
            b  = row["Coef"].values[0]
            p  = row["P_value"].values[0]
            r2b = r2c.loc[t,"HAR_RV"]      if t in r2c.index and "HAR_RV"      in r2c.columns else np.nan
            r2e = r2c.loc[t,"HAR_RV_ASVI"] if t in r2c.index and "HAR_RV_ASVI" in r2c.columns else np.nan
            dr2 = r2e - r2b if not (np.isnan(r2b) or np.isnan(r2e)) else np.nan
            lines.append(f"  {t:<6} {b:>+13.6f}  {p:>7.3f}{sig_stars(p):<3}  "
                         f"{r2b:>7.4f}  {r2e:>12.4f}  "
                         f"{dr2:>+6.4f}" if not np.isnan(dr2) else
                         f"  {t:<6} {b:>+13.6f}  {p:>7.3f}{sig_stars(p):<3}  "
                         f"{r2b:>7.4f}  {r2e:>12.4f}     N/A")
    else:
        lines.append("  HAR-RV not run or no results.")

    # ── GARCH
    lines += ["", "═"*72, "6. GARCH-ASVI RESULTS  [MLE]", "═"*72, ""]
    if garch_df is not None and not garch_df.empty:
        gd = garch_df[(garch_df["Model"]=="GARCH_ASVI") &
                      (garch_df["Param"]=="delta_asvi")].copy()
        g11p = garch_df[(garch_df["Model"]=="GARCH11")].groupby("Ticker")[
            "Persistence"].first()
        lines.append(f"  {'Ticker':<6} {'δ(ASVI)':>13} {'p':>7} "
                     f"{'Persistence':>12}  AIC")
        lines.append("  " + "─"*52)
        for t in COMPANY_ORDER:
            row = gd[gd["Ticker"]==t]
            if row.empty: continue
            b  = float(row["Estimate"].values[0])
            p  = float(row["P_value"].values[0]) if not pd.isna(row["P_value"].values[0]) else np.nan
            aic = float(row["AIC"].values[0])
            pers = g11p.get(t, np.nan)
            lines.append(f"  {t:<6} {b:>+13.6f} {p:>7.3f}{sig_stars(p):<3} "
                         f"{pers:>12.4f}  {aic:.1f}")
    else:
        lines.append("  GARCH not run or no results.")

    # ── QUANTILE REGRESSION
    lines += ["", "═"*72, "7. QUANTILE REGRESSION  [τ=0.25/0.50/0.75/0.90]", "═"*72, ""]
    if qr_df is not None and not qr_df.empty:
        qsub = qr_df[qr_df["Variable"]=="ASVI(t-1)"]
        lines.append(f"  {'Ticker':<6} "
                     + "  ".join([f"τ={t:.2f}" for t in QUANTILE_TAUS]))
        lines.append("  " + "─"*52)
        for t in COMPANY_ORDER:
            s_t = qsub[qsub["Ticker"]==t].set_index("Tau")
            if s_t.empty: continue
            vals = []
            for tau in QUANTILE_TAUS:
                if tau in s_t.index:
                    b = float(s_t.loc[tau,"Coef"])
                    vals.append(f"{b:>+7.4f}")
                else:
                    vals.append("    N/A")
            lines.append(f"  {t:<6} {'  '.join(vals)}")

    # ── POWER & FALSIFICATION
    lines += ["", "═"*72, "8. POWER/MDE + FALSIFICATION", "═"*72, ""]
    if pwr_df is not None and not pwr_df.empty:
        lines.append(f"  {'Ticker':<6} {'N':>5}  {'β_ASVI':>10}  "
                     f"{'MDE(80%)':>10}  {'Power':>8}  Status")
        lines.append("  " + "─"*58)
        for t in COMPANY_ORDER:
            row = pwr_df[pwr_df["Ticker"]==t]
            if row.empty: continue
            r = row.iloc[0]
            status = "UNDERPOWERED" if r["Underpowered"] else "OK"
            lines.append(f"  {t:<6} {r['N']:>5}  "
                         f"{r['Beta_ASVI']:>+10.5f}  "
                         f"{r['MDE_80pct']:>+10.5f}  "
                         f"{r['Actual_Power']:>8.1%}  {status}")
    if false_df is not None and not false_df.empty:
        lines.append("\n  Falsification (date-shuffled ASVI, 200 iter):")
        lines.append(f"  {'Ticker':<6} {'β_obs':>10}  {'β_shuffle':>12}  "
                     f"{'p_false':>8}  Conclusion")
        lines.append("  " + "─"*54)
        for t in COMPANY_ORDER:
            row = false_df[false_df["Ticker"]==t]
            if row.empty: continue
            r = row.iloc[0]
            lines.append(f"  {t:<6} {r['Beta_observed']:>+10.5f}  "
                         f"{r['Beta_shuffle_mean']:>+12.5f}  "
                         f"{r['P_false_twosided']:>8.3f}  {r['Conclusion']}")

    # ── PANEL FE
    lines += ["", "═"*72, "9. PANEL FE: NW-HAC vs DRISCOLL-KRAAY SE", "═"*72, ""]
    if panel_df is not None and not panel_df.empty:
        for mod in ["FE_M1","FE_M2"]:
            sub_p = panel_df[panel_df["Model"]==mod]
            if sub_p.empty: continue
            lab = sub_p["Label"].iloc[0]
            lines.append(f"\n  {lab}  N={sub_p['N'].iloc[0]}  R²={sub_p['R2_within'].iloc[0]:.4f}")
            lines.append(f"  {'Variable':<32} {'Coef':>10}  {'p_NW':>8}  {'p_DK':>8}")
            lines.append("  " + "─"*62)
            for _, r in sub_p.iterrows():
                lines.append(f"  {r['Variable']:<32} {r['Coef']:>+10.5f}  "
                              f"{r['P_NW']:>8.3f}{r.get('Sig_NW',''):<3}  "
                              f"{r['P_DK']:>8.3f}{r.get('Sig_DK',''):<3}")

    # ── SUBPERIOD / CHOW
    lines += ["", "═"*72, "10. SUBPERIOD + CHOW TEST", "═"*72, ""]
    if chow_df is not None and not chow_df.empty:
        n_break = (chow_df["P_Chow"] < 0.05).sum()
        lines.append(f"  Structural breaks @5%: {n_break}/{len(chow_df)}")
        lines.append(f"  {'Ticker':<6} {'F_Chow':>8}  {'P_Chow':>8}  Result")
        lines.append("  " + "─"*40)
        for _, r in chow_df.iterrows():
            fc = f"{r['F_Chow']:.3f}" if not np.isnan(r['F_Chow']) else "  N/A"
            pc = f"{r['P_Chow']:.3f}{sig_stars(r['P_Chow']):<3}" if not np.isnan(r['P_Chow']) else "  N/A"
            lines.append(f"  {r['Ticker']:<6} {fc:>8}  {pc:>8}  {r['Interpretation']}")

    # ── KEY REFERENCES
    lines += [
        "", "═"*72, "11. METHODOLOGY & KEY REFERENCES", "═"*72, "",
        "  ASVI:         Δln(SVI_MAX_t) − 8-week rolling median [Da et al. 2011]",
        "  Realized Vol: 4-week rolling std of |weekly return| [Vlastakis & Markellos 2012]",
        "  HAC SE:       Newey-West (1987), bandwidth=4",
        "  Panel FE:     Within-transformation (entity demeaning)",
        "  DK SE:        Driscoll-Kraay (1998) — spatial HAC",
        "  ADF:          MacKinnon (1994) response-surface p-values",
        "  HAR-RV:       Corsi (2009) — J. Financial Econometrics",
        "  GARCH:        Bollerslev (1986), L-BFGS-B MLE, delta method SE",
        "  QR:           Koenker & Bassett (1978), scipy highs LP",
        "  Bootstrap:    Moving-block, Politis & Romano (1994), B=1000",
        "  BH-FDR:       Benjamini & Hochberg (1995)",
        "  Chow:         Chow (1960)", "",
        "  [1] Da, Z., Engelberg, J., Gao, P. (2011). Journal of Finance 66(5).",
        "  [2] Vlastakis, N., Markellos, R. (2012). J. Banking & Finance 36(6).",
        "  [3] Corsi, F. (2009). J. Financial Econometrics 7(2), 174–196.",
        "  [4] Driscoll, J., Kraay, A. (1998). Review of Economics & Statistics 80(4).",
        "  [5] Newey, W., West, K. (1987). Econometrica 55(3), 703–708.",
        "  [6] Koenker, R., Bassett, G. (1978). Econometrica 46(1), 33–50.",
        "  [7] Barber, B., Odean, T. (2008). Review of Financial Studies 21(2).",
        "",
        "─"*72,
        f"  END OF REPORT v4  |  Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "─"*72,
    ]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    log(f"Analysis report saved: {path}", "OK")


def write_data_quality_report(qdata, winsor_log, vol_pct, path):
    lines = [
        "DATA QUALITY REPORT  v4",
        "="*70,
        f"Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Seed: {SEED}", "",
        "SUMMARY OF ISSUES", "-"*70,
    ]
    for iss in qdata.get("issues", []):
        tag = "[CRITICAL]" if "CRITICAL" in iss else "[INFO]"
        lines.append(f"  {tag} {iss}")
    cov = qdata.get("coverage")
    if cov is not None:
        lines += ["", "COVERAGE TABLE", "-"*70,
                  f"  {'Ticker':<6} {'Sector':<14} {'N':>4}  "
                  f"{'Close':>8}{'Return':>8}{'Vol':>7}{'ASVI':>7}{'LnVol':>7}",
                  "  "+"─"*58]
        for _, row in cov.iterrows():
            lines.append(f"  {row['Ticker']:<6} {row['Sector']:<14} {row['N']:>4}  "
                         f"{row.get('Close_pct',0):>7.1f}%"
                         f"{row.get('Weekly_Return_pct',0):>7.1f}%"
                         f"{row.get('Weekly_Volatility_pct',0):>6.1f}%"
                         f"{row.get('ASVI_pct',0):>6.1f}%"
                         f"{row.get('LnVol_pct',0):>6.1f}%")
    lines += ["", "WINSORISATION (per company)", "-"*70]
    for t, w in winsor_log.items():
        lines.append(f"  {t}: Returns {w.get('ret_n',0)} obs clipped "
                     f"[{w.get('ret_lo',np.nan):.4f}, {w.get('ret_hi',np.nan):.4f}]  "
                     f"| ASVI {w.get('asvi_n',0)} obs clipped")
    lines += ["", "VOLUME COVERAGE", "-"*70]
    for t, pct in sorted(vol_pct.items()):
        use = pct >= 60 and t not in INDEX_TICKERS
        lines.append(f"  {t}: {pct:5.1f}% → {'INCLUDED' if use else 'EXCLUDED'}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    log(f"Quality report saved: {path}", "OK")


# ═══════════════════════════════════════════════════════════════════════
# SECTION 19: SAVE ALL CSVs
# ═══════════════════════════════════════════════════════════════════════

def save_all(desc_df, gc_df, reg_df, boot_df, panel_df, sp_df,
             chow_df, corr_df, har_df, garch_df, qr_df,
             pwr_df, false_df, ev_df, pt_df):
    section("SAVING OUTPUT CSVs")
    saves = [
        (desc_df,   "DESCRIPTIVE_STATS.csv"),
        (gc_df,     "GRANGER_RESULTS.csv"),
        (reg_df,    "REGRESSION_RESULTS.csv"),
        (boot_df,   "BOOTSTRAP_CI.csv"),
        (panel_df,  "PANEL_REGRESSION_RESULTS.csv"),
        (sp_df,     "SUBPERIOD_RESULTS.csv"),
        (chow_df,   "CHOW_TEST_RESULTS.csv"),
        (corr_df,   "CORRELATION_RESULTS.csv"),
        (har_df,    "HAR_RV_RESULTS.csv"),
        (garch_df,  "GARCH_RESULTS.csv"),
        (qr_df,     "QUANTILE_REG_RESULTS.csv"),
        (pwr_df,    "POWER_MDE_RESULTS.csv"),
        (false_df,  "FALSIFICATION_RESULTS.csv"),
        (ev_df,     "EVENT_STUDY_RESULTS.csv"),
        (pt_df,     "PRETREND_RESULTS.csv"),
    ]
    for df_, name in saves:
        if df_ is None or (hasattr(df_,"empty") and df_.empty):
            log(f"  Skipped (empty): {name}", "WARN")
            continue
        path = os.path.join(OUTDIR, name)
        df_.to_csv(path, index=False, encoding="utf-8-sig")
        log(f"  Saved: {name}", "OK")


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

def main():
    os.makedirs(OUTDIR, exist_ok=True)
    os.makedirs(GDIR,   exist_ok=True)

    print("\n" + "╔"+"═"*68+"╗")
    print("║  THESIS ENGINE  v4  —  Investor Attention & Market Volatility    ║")
    print("╚"+"═"*68+"╝\n")

    section("LOAD AND PREPARE DATA")
    df, winsor_log, vol_pct, vol_nonstat = load_and_prepare()

    section("DATA QUALITY AUDIT")
    qdata = data_quality_audit(df, winsor_log)

    section("DESCRIPTIVE STATISTICS")
    desc_df = descriptive_stats(df)

    section("CORRELATION ANALYSIS")
    corr_df = correlation_analysis(df)

    section("GRANGER CAUSALITY")
    gc_df = granger_analysis(df)

    section("OLS REGRESSIONS")
    reg_df, boot_df = run_regressions(df)

    section("SUBPERIOD + CHOW")
    sp_df, chow_df = run_subperiod_regressions(df)

    section("PANEL FE")
    panel_df = run_panel_regressions(df)

    # ── New v4 modules
    har_df   = run_har_rv(df)
    garch_df = run_garch(df)
    qr_df    = run_quantile_regressions(df)
    ev_df    = run_event_study(df, threshold_sd=1.5, window=4)
    pt_df    = run_pretrend_analysis(df)
    pwr_df   = run_power_analysis(df, reg_df)
    false_df = run_falsification(df, n_iter=N_FALSE)

    # ── Charts
    plot_summary_panels(df, reg_df, gc_df, boot_df, har_df,
                         garch_df, qr_df, ev_df, pwr_df, false_df)

    # ── Save CSVs
    save_all(desc_df, gc_df, reg_df, boot_df, panel_df, sp_df,
             chow_df, corr_df, har_df, garch_df, qr_df,
             pwr_df, false_df, ev_df, pt_df)

    # ── Write reports
    section("WRITING REPORTS")
    write_data_quality_report(
        qdata, winsor_log, vol_pct,
        os.path.join(OUTDIR, "DATA_QUALITY_REPORT_v4.txt"))
    write_analysis_report(
        df, desc_df, gc_df, reg_df, boot_df, panel_df,
        sp_df, chow_df, har_df, garch_df, qr_df,
        pwr_df, false_df, ev_df, pt_df,
        os.path.join(OUTDIR, "ANALYSIS_REPORT_v4.txt"))

    # ── Manifest (FIX 15)
    _MANIFEST["summaries"]["vol_nonstat"]  = sorted(vol_nonstat)
    _MANIFEST["summaries"]["n_granger_h1"] = int(
        (gc_df[(gc_df["Hypothesis"]=="H1: ASVI→Vol") &
               (gc_df["Lag"]==1)]["P_param"] < 0.05).sum())
    _MANIFEST["summaries"]["n_m1_sig"]     = int(
        (reg_df[(reg_df["Model"]=="M1") &
                (reg_df["Variable"]=="ASVI(t-1)")]["P_value"] < 0.05).sum())
    _MANIFEST["summaries"]["n_har_asvi_sig"] = int(
        (har_df[har_df["Variable"]=="γ_ASVI"]["P_value"] < 0.05).sum()
    ) if har_df is not None and not har_df.empty else 0
    _save_manifest()

    elapsed = round(time.time() - _T0, 1)
    print(f"\n  {'═'*68}")
    print(f"  ENGINE v4 COMPLETE  |  {elapsed}s elapsed")
    print(f"  Output → {OUTDIR}")
    print(f"  {'═'*68}\n")

    return {
        "desc": desc_df, "granger": gc_df, "reg": reg_df,
        "boot": boot_df, "panel": panel_df, "subperiod": sp_df,
        "chow": chow_df, "corr": corr_df, "har": har_df,
        "garch": garch_df, "qr": qr_df, "power": pwr_df,
        "false": false_df, "event": ev_df, "pretrend": pt_df,
    }


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
